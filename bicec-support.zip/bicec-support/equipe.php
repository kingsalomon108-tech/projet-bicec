<?php
require_once 'config/db.php';
require_once 'includes/auth.php';
exiger_connexion();

$titre = 'Équipe';
$u = utilisateur_actuel();

include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/bg.php';
?>

<div class="page-header">
    <div>
        <h1>Équipe Support</h1>
        <p class="subtitle">Membres actifs et leur charge de travail</p>
    </div>
    <?php if (est_chef()): ?>
        <button class="btn btn-accent" onclick="ouvrirModalMembre()">
            <i data-lucide="user-plus"></i> Ajouter un membre
        </button>
    <?php endif; ?>
</div>

<div id="equipe-container" class="equipe-grid">
    <div class="loading">Chargement</div>
</div>

<!-- Modal Ajouter membre (chef) -->
<?php if (est_chef()): ?>
<div id="modal-membre" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Ajouter un membre</h2>
            <button class="modal-close" onclick="fermerModalMembre()">
                <i data-lucide="x"></i>
            </button>
        </div>
        <form id="form-membre" onsubmit="soumettreMembre(event)">
            <label>Nom complet *</label>
            <input type="text" id="membre-nom" required placeholder="Ex : Jean Dupont">

            <label>Email *</label>
            <input type="email" id="membre-email" required placeholder="jean.dupont@bicec.cm">

            <label>Mot de passe *</label>
            <input type="text" id="membre-mdp" required placeholder="Mot de passe initial">

            <label>Rôle</label>
            <select id="membre-role">
                <option value="membre" selected>Membre</option>
                <option value="chef">Chef d'équipe</option>
            </select>

            <div class="modal-actions">
                <button type="button" class="btn btn-ghost" onclick="fermerModalMembre()">Annuler</button>
                <button type="submit" class="btn btn-primary">
                    <i data-lucide="user-plus"></i> Créer
                </button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- Modal Détail membre -->
<div id="modal-membre-detail" class="modal">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h2 id="detail-membre-titre">Tâches du membre</h2>
            <button class="modal-close" onclick="fermerDetailMembre()">
                <i data-lucide="x"></i>
            </button>
        </div>
        <div id="detail-membre-body"></div>
    </div>
</div>

<?php include 'includes/bg-end.php'; ?>
<?php include 'includes/footer.php'; ?>