// ============================================
//  BICEC Support — Application JS (corrigé)
// ============================================

const API = 'api/';

// ============================================
//  HELPERS API
// ============================================
function apiGet(url, params = {}) {
    const q = new URLSearchParams(params).toString();
    return fetch(`${API}${url}${q ? '?' + q : ''}`).then(r => r.json());
}

function apiPost(url, data = {}) {
    return fetch(`${API}${url}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).then(r => r.json());
}

// ============================================
//  HELPERS TEXTE / DATE
// ============================================
function escapeHtml(s) {
    if (s === null || s === undefined) return '';
    return String(s).replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

function formatDate(d) {
    if (!d) return '';
    const date = new Date(d);
    return date.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}

function statutLabel(s) {
    return {
        'a_faire': 'À faire',
        'en_cours': 'En cours',
        'en_attente_validation': 'En attente',
        'valide': 'Validé'
    }[s] || s;
}

// ============================================
//  TOASTS
// ============================================
function initToastContainer() {
    if (!document.querySelector('.toast-container')) {
        const c = document.createElement('div');
        c.className = 'toast-container';
        document.body.appendChild(c);
    }
}

function toast(message, type = 'success') {
    initToastContainer();
    const icons = {
        success: 'check-circle-2',
        error: 'x-circle',
        warning: 'alert-triangle',
        info: 'info'
    };
    const el = document.createElement('div');
    el.className = 'toast ' + type;
    el.innerHTML = '<i data-lucide="' + (icons[type] || 'info') + '"></i><span>' + escapeHtml(message) + '</span>';
    document.querySelector('.toast-container').appendChild(el);

    if (window.lucide) lucide.createIcons({ nodes: [el] });

    setTimeout(() => {
        el.style.animation = 'toastOut .3s ease forwards';
        setTimeout(() => el.remove(), 300);
    }, 3200);
}

// ============================================
//  CONFIRMATION STYLÉE
// ============================================
function confirmer(message, titre = 'Confirmation') {
    return new Promise(resolve => {
        const modal = document.createElement('div');
        modal.className = 'modal open';
        modal.innerHTML = `
            <div class="modal-content" style="max-width:400px">
                <div class="modal-header">
                    <h2>${escapeHtml(titre)}</h2>
                    <button class="modal-close" data-annuler>
                        <i data-lucide="x"></i>
                    </button>
                </div>
                <div style="padding: 22px 26px;">
                    <p style="color: var(--text-soft); line-height:1.6; font-size:14px;">
                        ${escapeHtml(message)}
                    </p>
                    <div class="modal-actions">
                        <button class="btn btn-ghost" data-annuler>Annuler</button>
                        <button class="btn btn-primary" data-ok>Confirmer</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        if (window.lucide) lucide.createIcons({ nodes: [modal] });

        const close = (val) => { modal.remove(); resolve(val); };
        modal.querySelectorAll('[data-ok]').forEach(b => b.onclick = () => close(true));
        modal.querySelectorAll('[data-annuler]').forEach(b => b.onclick = () => close(false));
        modal.addEventListener('click', e => { if (e.target === modal) close(false); });
    });
}

// ============================================
//  PROMPT MOTIF (pour refus)
// ============================================
function promptMotif(titre = 'Motif du refus') {
    return new Promise(resolve => {
        const modal = document.createElement('div');
        modal.className = 'modal open';
        modal.innerHTML = `
            <div class="modal-content" style="max-width:440px">
                <div class="modal-header">
                    <h2>${escapeHtml(titre)}</h2>
                    <button class="modal-close" data-annuler>
                        <i data-lucide="x"></i>
                    </button>
                </div>
                <div style="padding: 22px 26px;">
                    <label style="display:block;margin-bottom:8px;font-weight:600;font-size:13px;color:var(--text-soft);">
                        Expliquez pourquoi cette tâche est refusée :
                    </label>
                    <textarea id="prompt-motif-input" rows="3" placeholder="Motif..." style="width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:8px;font-family:inherit;font-size:14px;background:var(--bg);"></textarea>
                    <div class="modal-actions">
                        <button class="btn btn-ghost" data-annuler>Annuler</button>
                        <button class="btn btn-primary" data-ok>Envoyer</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        if (window.lucide) lucide.createIcons({ nodes: [modal] });

        const input = modal.querySelector('#prompt-motif-input');
        input.focus();

        const close = (val) => { modal.remove(); resolve(val); };
        modal.querySelectorAll('[data-ok]').forEach(b => b.onclick = () => close(input.value.trim()));
        modal.querySelectorAll('[data-annuler]').forEach(b => b.onclick = () => close(null));
        modal.addEventListener('click', e => { if (e.target === modal) close(null); });
    });
}

// ============================================
//  LISTE DES TÂCHES
// ============================================
let tachesCourantes = [];

let pageCourante = 1;

async function chargerTaches(page = 1) {
    const tbody = document.getElementById('tickets-tbody');
    if (!tbody) return;

    pageCourante = page;
    tbody.innerHTML = '<tr><td colspan="10" class="loading-cell">Chargement</td></tr>';

    const params = {
        page: page,
        statut: document.getElementById('filtre-statut')?.value || '',
        priorite: document.getElementById('filtre-priorite')?.value || '',
        categorie: document.getElementById('filtre-categorie')?.value || '',
        q: document.getElementById('filtre-recherche')?.value || ''
    };

    try {
        const data = await apiGet('taches_paginees.php', params);
        afficherTickets(data);
    } catch (e) {
        tbody.innerHTML = '<tr><td colspan="10" class="empty-cell">Erreur de chargement.</td></tr>';
    }
}

function afficherTickets(data) {
    const tbody = document.getElementById('tickets-tbody');

    if (!data.taches.length) {
        tbody.innerHTML = '<tr><td colspan="10" class="empty-cell">Aucun ticket.</td></tr>';
        document.getElementById('pagination').innerHTML = '';
        return;
    }

    tbody.innerHTML = data.taches.map(ligneTicket).join('');
    afficherPagination(data.page, data.total_pages);

    if (window.lucide) lucide.createIcons();
}

function ligneTicket(t) {
    const retard = parseInt(t.en_retard) === 1;
    const statutLabels = {
        'a_faire': 'À faire',
        'en_cours': 'En cours',
        'en_attente_validation': 'En attente',
        'valide': 'Validé'
    };

    const echeance = t.date_echeance ? new Date(t.date_echeance).toLocaleDateString('fr-FR', {
        day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'
    }) : '-';

    const actions = [];
const estChef = window.ROLE === 'chef';

// Un technicien peut démarrer/terminer ses tickets
if (!estChef) {
    if (t.statut === 'a_faire') {
        actions.push(`<button class="btn-icon-sm" onclick="changerStatut(${t.id},'en_cours')" title="Démarrer"><i data-lucide="play"></i></button>`);
    }
    if (t.statut === 'en_cours') {
        actions.push(`<button class="btn-icon-sm success" onclick="changerStatut(${t.id},'en_attente_validation')" title="Terminer"><i data-lucide="check"></i></button>`);
    }
    // Bouton réassigner (chef uniquement)

}
  if (estChef) {
        actions.push(`<button class="btn-icon-sm" onclick="ouvrirReassignation(${t.id})" title="Réassigner"><i data-lucide="user-plus"></i></button>`);
    }

actions.push(`<button class="btn-icon-sm" onclick="ouvrirDetail(${t.id})" title="Voir"><i data-lucide="eye"></i></button>`);
actions.push(`<button class="btn-icon-sm" onclick="ouvrirModalTache(${t.id})" title="Modifier"><i data-lucide="pencil"></i></button>`);
    return `
        <tr class="${retard ? 'ligne-retard' : ''}">
            <td class="cell-ref">
                ${retard ? '<i data-lucide="alert-circle" class="icon-retard"></i>' : ''}
                <span>${escapeHtml(t.reference || '-')}</span>
            </td>
            <td>${escapeHtml(t.type_ticket || 'incident')}</td>
            <td class="cell-titre" onclick="ouvrirDetail(${t.id})">
                ${escapeHtml(t.titre)}
            </td>
            <td><span class="badge-cat">${escapeHtml(t.categorie || '-')}</span></td>
            <td>${escapeHtml(t.assigne_nom || '<em>Non assigné</em>')}</td>
            <td>
    ${t.demandeur_nom ? escapeHtml(t.demandeur_nom) : '-'}
    ${t.siege ? `<br><small style="color:var(--muted);">${escapeHtml(t.siege)}</small>` : ''}
</td>
            <td><span class="badge-prio badge-prio-${t.priorite}">${t.priorite}</span></td>
            <td><span class="badge-statut badge-statut-${t.statut}">${statutLabels[t.statut] || t.statut}</span></td>
            <td class="cell-echeance ${retard ? 'texte-retard' : ''}">${echeance}</td>
            <td>${escapeHtml(t.service_concerne || '-')}</td>
            <td class="cell-actions">${actions.join(' ')}</td>
        </tr>
    `;
}

function afficherPagination(page, total) {
    const div = document.getElementById('pagination');
    if (total <= 1) { div.innerHTML = ''; return; }

    let html = '<div class="pagination-inner">';

    // Bouton précédent
    html += `<button class="page-btn" ${page === 1 ? 'disabled' : ''} onclick="chargerTaches(${page - 1})">
        <i data-lucide="chevron-left"></i>
    </button>`;

    // Pages
    const debut = Math.max(1, page - 2);
    const fin = Math.min(total, page + 2);

    if (debut > 1) {
        html += `<button class="page-btn" onclick="chargerTaches(1)">1</button>`;
        if (debut > 2) html += '<span class="page-dots">...</span>';
    }

    for (let i = debut; i <= fin; i++) {
        html += `<button class="page-btn ${i === page ? 'active' : ''}" onclick="chargerTaches(${i})">${i}</button>`;
    }

    if (fin < total) {
        if (fin < total - 1) html += '<span class="page-dots">...</span>';
        html += `<button class="page-btn" onclick="chargerTaches(${total})">${total}</button>`;
    }

    // Bouton suivant
    html += `<button class="page-btn" ${page === total ? 'disabled' : ''} onclick="chargerTaches(${page + 1})">
        <i data-lucide="chevron-right"></i>
    </button>`;

    html += '</div>';
    div.innerHTML = html;

    if (window.lucide) lucide.createIcons({ nodes: [div] });
}

// Calcul automatique du SLA
async function majerSla() {
    const cat = document.getElementById('tache-categorie')?.value;
    const prio = document.getElementById('tache-priorite')?.value;
    if (!cat || !prio) return;

    const sla = await apiGet('sla_calcul.php', { categorie: cat, priorite: prio });
    const el = document.getElementById('sla-text');
    if (el) {
        el.textContent = `SLA : ${sla.heures}h — Échéance prévue : ${sla.date_affichage}`;
    }
}

function carteTache(t) {
    const retard = t.date_echeance && new Date(t.date_echeance) < new Date() && t.statut !== 'valide';
    const motifBloc = t.motif_refus
        ? '<div class="motif-refus"><i data-lucide="alert-triangle"></i><div><strong>Refusée par le chef</strong><p>' + escapeHtml(t.motif_refus) + '</p></div></div>'
        : '';
    const descBloc = t.description
        ? '<p class="carte-desc">' + escapeHtml(t.description) + '</p>'
        : '';
    const dateBloc = t.date_echeance
        ? '<span class="badge ' + (retard ? 'badge-urgente' : 'badge-normale') + '"><i data-lucide="calendar"></i> ' + formatDate(t.date_echeance) + '</span>'
        : '';
    const assigneBloc = t.assigne_nom ? escapeHtml(t.assigne_nom) : '<em>Non assignée</em>';
    const chefActions = window.ROLE === 'chef'
        ? '<button class="icon-btn danger" onclick="supprimerTache(' + t.id + ')" title="Supprimer"><i data-lucide="trash-2"></i></button>'
        : '';
    const estChef = window.ROLE === 'chef';
const btnDemarrer = (!estChef && t.statut === 'a_faire')
    ? '<button class="btn-mini" onclick="changerStatut(' + t.id + ',\'en_cours\')"><i data-lucide="play"></i> Démarrer</button>'
    : '';
const btnTerminer = (!estChef && t.statut === 'en_cours')
    ? '<button class="btn-mini success" onclick="changerStatut(' + t.id + ',\'en_attente_validation\')"><i data-lucide="check"></i> Terminer</button>'
    : '';
const btnValidation = '';
    return `
        <div class="carte-tache ${retard ? 'retard' : ''}" data-id="${t.id}">
            <div class="carte-header">
                <div class="carte-titre" onclick="ouvrirDetail(${t.id})">
                    ${escapeHtml(t.titre)}
                </div>
                <div class="carte-actions">
                    <button class="icon-btn" onclick="ouvrirModalTache(${t.id})" title="Modifier">
                        <i data-lucide="pencil"></i>
                    </button>
                    ${chefActions}
                </div>
            </div>

            ${motifBloc}
            ${descBloc}

            <div class="carte-badges">
                <span class="badge badge-${t.statut}">${statutLabel(t.statut)}</span>
                <span class="badge badge-${t.priorite}">${t.priorite}</span>
                ${dateBloc}
            </div>

            <div class="carte-progress">
                <div class="progress-bar"><span style="width:${t.avancement}%"></span></div>
                <span class="progress-pct">${t.avancement}%</span>
            </div>

            <div class="carte-footer">
                <div class="assigne">
                    <i data-lucide="user"></i> ${assigneBloc}
                </div>
                <div class="carte-meta" onclick="ouvrirDetail(${t.id})" style="cursor:pointer;" title="Voir les commentaires">
    <i data-lucide="message-square"></i> ${t.nb_commentaires}
</div>
            </div>

            <div class="carte-quick">
                ${btnDemarrer}
                ${btnTerminer}
                ${btnValidation}
            </div>
        </div>
    `;
}

// ============================================
//  MODAL TÂCHE (création / édition)
// ============================================
function ouvrirModalTache(id = null) {
    const modal = document.getElementById('modal-tache');
    if (!modal) return;
    modal.classList.add('open');
    document.getElementById('form-tache').reset();
    document.getElementById('tache-id').value = '';

    if (id) {
        document.getElementById('modal-titre').textContent = 'Modifier la tâche';
        apiGet('tache_detail.php', { id }).then(data => {
            const t = data.tache;
            document.getElementById('tache-id').value = t.id;
            document.getElementById('tache-titre').value = t.titre;
            document.getElementById('tache-description').value = t.description || '';
            document.getElementById('tache-priorite').value = t.priorite;
            const echEl = document.getElementById('tache-echeance');
            if (echEl) echEl.value = t.date_echeance || '';
            const catEl = document.getElementById('tache-categorie');
            if (catEl && t.categorie) catEl.value = t.categorie;

            const servEl = document.getElementById('tache-service');
            if (servEl) servEl.value = t.service_concerne || '';
const siegeEl = document.getElementById('tache-siege');
if (siegeEl) siegeEl.value = t.siege || '';

const demNomEl = document.getElementById('tache-demandeur-nom');
if (demNomEl) demNomEl.value = t.demandeur_nom || '';

const demServEl = document.getElementById('tache-demandeur-service');
if (demServEl) demServEl.value = t.demandeur_service || '';
            const assigneEl = document.getElementById('tache-assigne');
            if (assigneEl) assigneEl.value = t.assigne_a_id || '';
        });
    } else {
        document.getElementById('modal-titre').textContent = 'Nouvelle tâche';
    }

    if (window.lucide) lucide.createIcons({ nodes: [modal] });
}

function fermerModalTache() {
    const m = document.getElementById('modal-tache');
    if (m) m.classList.remove('open');
}
async function soumettreTache(e) {
    e.preventDefault();

    const titre = document.getElementById('tache-titre').value.trim();
    if (!titre) {
        toast('Le titre est obligatoire', 'error');
        return;
    }

    const id = document.getElementById('tache-id').value;

    // Construction sécurisée du FormData
    const formData = new FormData();
    formData.append('titre', titre);
    formData.append('description', document.getElementById('tache-description')?.value || '');
    formData.append('type_ticket', document.getElementById('tache-type')?.value || 'incident');
    formData.append('categorie', document.getElementById('tache-categorie')?.value || 'autre');
    formData.append('priorite', document.getElementById('tache-priorite')?.value || 'normale');
    formData.append('service_concerne', document.getElementById('tache-service')?.value || '');
    formData.append('siege', document.getElementById('tache-siege')?.value || '');
    formData.append('demandeur_nom', document.getElementById('tache-demandeur-nom')?.value || '');
    formData.append('demandeur_service', document.getElementById('tache-demandeur-service')?.value || '');
    // Échéance : le champ peut ne pas exister (SLA auto)
    const echeanceEl = document.getElementById('tache-echeance');
    formData.append('date_echeance', echeanceEl ? echeanceEl.value : '');

    // Assignation
    const assigneEl = document.getElementById('tache-assigne');
    formData.append('assigne_a_id', assigneEl ? assigneEl.value : '');

    if (id) formData.append('id', id);

    // Pièces jointes
    const fichiersInput = document.getElementById('tache-fichiers');
    if (fichiersInput && fichiersInput.files.length) {
        for (let i = 0; i < fichiersInput.files.length; i++) {
            formData.append('fichiers[]', fichiersInput.files[i]);
        }
    }

    const url = id ? 'tache_update.php' : 'tache_create.php';

    try {
        const res = await fetch(API + url, {
            method: 'POST',
            body: formData
        }).then(r => r.json());

        if (res.success) {
            fermerModalTache();
            toast(id ? 'Ticket modifié' : 'Ticket créé avec succès', 'success');
            chargerTaches();
        } else {
            toast(res.error || 'Erreur', 'error');
        }
    } catch (err) {
        console.error(err);
        toast('Erreur réseau', 'error');
    }
}
// ============================================
//  ACTIONS RAPIDES
// ============================================
async function changerStatut(id, statut) {
    const res = await apiPost('tache_statut.php', { id, statut });
    if (res.success) {
        toast('Statut mis à jour', 'success');
        chargerTaches();
    } else {
        toast(res.error || 'Erreur', 'error');
    }
}

async function validerTache(id, action) {
    let motif = '';
    if (action === 'refuser') {
        motif = await promptMotif('Motif du refus');
        if (!motif) return;
    }
    const res = await apiPost('tache_valider.php', { id, action, motif });
    if (res.success) {
        toast(action === 'valider' ? 'Tâche validée' : 'Tâche refusée', 'success');
        chargerTaches();
    } else {
        toast(res.error || 'Erreur', 'error');
    }
}

async function supprimerTache(id) {
    const ok = await confirmer('Cette action est irréversible. Supprimer cette tâche ?', 'Suppression');
    if (!ok) return;
    const res = await apiPost('tache_delete.php', { id });
    if (res.success) {
        toast('Tâche supprimée', 'success');
        chargerTaches();
    } else {
        toast(res.error || 'Erreur', 'error');
    }
}

// ============================================
//  DÉTAIL TÂCHE + COMMENTAIRES
// ============================================
async function ouvrirDetail(id) {
    const modal = document.getElementById('modal-detail');
    const body = document.getElementById('detail-body');
    if (!modal || !body) return;

    body.innerHTML = '<div class="loading">Chargement</div>';
    modal.classList.add('open');

    const data = await apiGet('tache_detail.php', { id });
    if (!data || !data.tache) {
        body.innerHTML = '<div class="empty">Tâche introuvable ou accès refusé.</div>';
        return;
    }
    const t = data.tache;

    if (t.motif_refus && t.statut === 'en_cours') {
        toast('Tâche refusée : ' + t.motif_refus, 'warning');
    }

    const motifBloc = t.motif_refus
        ? '<div class="motif-refus-detail"><div class="motif-refus-header"><i data-lucide="alert-triangle"></i><strong>Tâche refusée</strong></div><p>' + escapeHtml(t.motif_refus) + '</p></div>'
        : '';

    const commentairesBloc = data.commentaires.length
        ? data.commentaires.map(c =>
            '<div class="commentaire"><div class="commentaire-header"><strong>' + escapeHtml(c.auteur) + '</strong><span class="date">' + formatDate(c.date_creation) + '</span></div><p>' + escapeHtml(c.contenu) + '</p></div>'
        ).join('')
        : '<p class="empty">Aucun commentaire.</p>';

    const piecesBloc = (data.pieces && data.pieces.length)
        ? data.pieces.map(p =>
            '<div class="piece-jointe"><i data-lucide="paperclip"></i><a href="' + p.chemin + '" target="_blank">' + escapeHtml(p.nom_fichier) + '</a><span class="date">' + formatDate(p.date_upload) + '</span></div>'
        ).join('')
        : '<p class="empty">Aucune pièce jointe.</p>';

    const historiqueBloc = data.historique.length
        ? data.historique.map(h =>
            '<li><span><strong>' + escapeHtml(h.auteur) + '</strong> — ' + escapeHtml(h.action) + (h.nouvelle_valeur ? ' <em>→ ' + escapeHtml(h.nouvelle_valeur) + '</em>' : '') + '</span><span class="date">' + formatDate(h.date_creation) + '</span></li>'
        ).join('')
        : '<li class="empty">Aucun historique.</li>';

    body.innerHTML = `
    <div class="detail-section">
        <h3>${escapeHtml(t.titre)}</h3>
        <div class="carte-badges" style="margin-top:10px;">
            <span class="badge badge-${t.statut}">${statutLabel(t.statut)}</span>
            <span class="badge badge-${t.priorite}">${t.priorite}</span>
            ${t.categorie ? '<span class="badge badge-normale">' + escapeHtml(t.categorie) + '</span>' : ''}
        </div>
        <p class="detail-desc">${escapeHtml(t.description || 'Aucune description')}</p>
        <div class="detail-info">
    <div><strong>Créateur :</strong> ${escapeHtml(t.createur_nom || '-')}</div>
    <div><strong>Assigné à :</strong> ${escapeHtml(t.assigne_nom || 'Personne')}</div>
    <div><strong>Service concerné :</strong> ${escapeHtml(t.service_concerne || '-')}</div>
    <div><strong>Siège :</strong> ${escapeHtml(t.siege || '-')}</div>
    <div><strong>Demandeur :</strong> ${escapeHtml(t.demandeur_nom || '-')}</div>
    <div><strong>Service demandeur :</strong> ${escapeHtml(t.demandeur_service || '-')}</div>
    <div><strong>Échéance :</strong> ${t.date_echeance || '-'}</div>
    <div><strong>Avancement :</strong> ${t.avancement}%</div>
</div>
        ${motifBloc}
    </div>

    <div class="detail-section">
        <h4>Pièces jointes</h4>
        <div class="pieces-jointes">${piecesBloc}</div>
    </div>

    <div class="detail-section">
        <h4>Commentaires (${data.commentaires.length})</h4>
        <div class="commentaires">${commentairesBloc}</div>
        <div class="ajout-commentaire">
            <textarea id="nouveau-commentaire" rows="2" placeholder="Écrire un commentaire..."></textarea>
            <button class="btn btn-primary" onclick="ajouterCommentaire(${id})">
                Envoyer
            </button>
        </div>
    </div>

    <div class="detail-section">
        <h4>Historique</h4>
        <ul class="historique">${historiqueBloc}</ul>
    </div>
`;

    if (window.lucide) lucide.createIcons({ nodes: [modal] });
}

function fermerModalDetail() {
    const m = document.getElementById('modal-detail');
    if (m) m.classList.remove('open');
}

async function ajouterCommentaire(id) {
    console.log('ajouterCommentaire appelée avec id =', id);

    const el = document.getElementById('nouveau-commentaire');
    if (!el) {
        console.error('Champ #nouveau-commentaire introuvable');
        toast('Erreur : champ commentaire introuvable', 'error');
        return;
    }

    const contenu = el.value.trim();
    console.log('Contenu à envoyer :', contenu);

    if (!contenu) {
        toast('Le commentaire est vide', 'warning');
        el.focus();
        return;
    }

    try {
        const res = await apiPost('commentaire_add.php', { tache_id: id, contenu });
        console.log('Réponse API :', res);

        if (res.success) {
            toast('Commentaire ajouté', 'success');
            await ouvrirDetail(id);
        } else {
            toast(res.error || 'Erreur', 'error');
        }
    } catch (err) {
        console.error('Erreur fetch :', err);
        toast('Erreur réseau', 'error');
    }
}

// ============================================
//  PAGE ÉQUIPE
// ============================================
async function chargerEquipe() {
    const container = document.getElementById('equipe-container');
    if (!container) return;
    container.innerHTML = '<div class="loading">Chargement</div>';

    try {
        const users = await apiGet('user_stats.php');
        afficherEquipe(users);
    } catch (e) {
        container.innerHTML = '<div class="empty">Erreur de chargement.</div>';
    }
}

function afficherEquipe(users) {
    const container = document.getElementById('equipe-container');
    if (!container) return;

    if (!users.length) {
        container.innerHTML = '<div class="empty-state"><p>Aucun membre.</p></div>';
        return;
    }

    container.innerHTML = users.map(carteMembre).join('');
    if (window.lucide) lucide.createIcons();
}

function carteMembre(u) {
    const initiale = (u.nom || '?').charAt(0).toUpperCase();
    const isChef = u.role === 'chef';
    const inactif = parseInt(u.actif) === 0;
    const badgeInactif = inactif ? '<div class="badge-inactif">Désactivé</div>' : '';
    const badgeRetard = parseInt(u.en_retard) > 0
        ? '<div class="badge badge-urgente" style="justify-content:center;"><i data-lucide="alert-circle"></i> ' + u.en_retard + ' tâche(s) en retard</div>'
        : '';
    const btnToggle = window.ROLE === 'chef'
        ? '<button class="btn-mini ' + (inactif ? 'success' : 'danger') + '" onclick="toggleMembre(' + u.id + ')"><i data-lucide="' + (inactif ? 'user-check' : 'user-x') + '"></i> ' + (inactif ? 'Activer' : 'Désactiver') + '</button>'
        : '';

    return `
        <div class="carte-membre ${inactif ? 'inactif' : ''}">
            ${badgeInactif}
            <div class="membre-header">
                <div class="membre-avatar ${isChef ? 'chef' : ''}">${initiale}</div>
                <div class="membre-info">
                    <div class="membre-nom">${escapeHtml(u.nom)}</div>
                    <div class="membre-role ${isChef ? 'chef' : ''}">
                        <i data-lucide="${isChef ? 'crown' : 'user'}"></i>
                        ${isChef ? 'Chef d\'équipe' : 'Membre'}
                    </div>
                    <div class="membre-email">${escapeHtml(u.email)}</div>
                </div>
            </div>

            <div class="membre-stats">
                <div class="membre-stat">
                    <div class="membre-stat-value">${u.total_taches}</div>
                    <div class="membre-stat-label">Total</div>
                </div>
                <div class="membre-stat">
                    <div class="membre-stat-value warning">${u.en_cours}</div>
                    <div class="membre-stat-label">En cours</div>
                </div>
                <div class="membre-stat">
                    <div class="membre-stat-value success">${u.validees}</div>
                    <div class="membre-stat-label">Validées</div>
                </div>
            </div>

            <div class="membre-progress">
                <div class="membre-progress-header">
                    <span>Taux de complétion</span>
                    <span>${u.taux}%</span>
                </div>
                <div class="progress-bar"><span style="width:${u.taux}%"></span></div>
            </div>

            ${badgeRetard}

            <div class="membre-actions">
                <button class="btn-mini" onclick="voirTachesMembre(${u.id}, '${escapeHtml(u.nom).replace(/'/g, "\\'")}')">
                    <i data-lucide="list-checks"></i> Voir les tâches
                </button>
                ${btnToggle}
            </div>
        </div>
    `;
}

// ---- Modal Ajouter membre ----
function ouvrirModalMembre() {
    const m = document.getElementById('modal-membre');
    if (!m) return;
    m.classList.add('open');
    document.getElementById('form-membre').reset();
    if (window.lucide) lucide.createIcons({ nodes: [m] });
}

function fermerModalMembre() {
    const m = document.getElementById('modal-membre');
    if (m) m.classList.remove('open');
}

async function soumettreMembre(e) {
    e.preventDefault();
    const data = {
        nom: document.getElementById('membre-nom').value,
        email: document.getElementById('membre-email').value,
        mot_de_passe: document.getElementById('membre-mdp').value,
        role: document.getElementById('membre-role').value
    };

    const res = await apiPost('user_create.php', data);
    if (res.success) {
        fermerModalMembre();
        toast('Membre créé avec succès', 'success');
        chargerEquipe();
    } else {
        toast(res.error || 'Erreur', 'error');
    }
}

async function toggleMembre(id) {
    const ok = await confirmer('Voulez-vous changer l\'état de ce membre ?', 'Confirmation');
    if (!ok) return;
    const res = await apiPost('user_toggle.php', { id });
    if (res.success) {
        toast(res.actif ? 'Membre activé' : 'Membre désactivé', 'success');
        chargerEquipe();
    } else {
        toast(res.error || 'Erreur', 'error');
    }
}
// ---- Voir tâches d'un membre ----
async function voirTachesMembre(id, nom) {
    const modal = document.getElementById('modal-membre-detail');
    const body = document.getElementById('detail-membre-body');
    if (!modal || !body) return;

    document.getElementById('detail-membre-titre').textContent = 'Tâches de ' + nom;
    body.innerHTML = '<div class="loading">Chargement</div>';
    modal.classList.add('open');

    const taches = await apiGet('taches_user.php', { id });

    if (!taches.length) {
        body.innerHTML = `
            <div style="padding:60px 20px;text-align:center;color:var(--muted);">
                <div style="font-size:48px;opacity:.3;margin-bottom:10px;">📭</div>
                <p>Aucune tâche assignée à ce membre.</p>
            </div>`;
        return;
    }

    // Statistiques du membre
    const stats = {
        total: taches.length,
        enCours: taches.filter(t => t.statut === 'en_cours').length,
        validees: taches.filter(t => t.statut === 'valide').length,
        enAttente: taches.filter(t => t.statut === 'en_attente_validation').length,
        retard: taches.filter(t => {
            return t.date_echeance && new Date(t.date_echeance) < new Date() && t.statut !== 'valide';
        }).length
    };

    // En-tête avec stats
    const statsBloc = `
        <div class="membre-detail-stats">
            <div class="mds-item">
                <div class="mds-value">${stats.total}</div>
                <div class="mds-label">Total</div>
            </div>
            <div class="mds-item warning">
                <div class="mds-value">${stats.enCours}</div>
                <div class="mds-label">En cours</div>
            </div>
            <div class="mds-item">
                <div class="mds-value">${stats.enAttente}</div>
                <div class="mds-label">En attente</div>
            </div>
            <div class="mds-item success">
                <div class="mds-value">${stats.validees}</div>
                <div class="mds-label">Validées</div>
            </div>
            <div class="mds-item danger">
                <div class="mds-value">${stats.retard}</div>
                <div class="mds-label">En retard</div>
            </div>
        </div>
    `;

    // Liste des tâches détaillées
    const tachesBloc = taches.map(t => {
        const retard = t.date_echeance && new Date(t.date_echeance) < new Date() && t.statut !== 'valide';
        
        const echeance = t.date_echeance
            ? new Date(t.date_echeance).toLocaleDateString('fr-FR', {
                day: '2-digit', month: '2-digit', year: 'numeric',
                hour: '2-digit', minute: '2-digit'
              })
            : '-';

        return `
            <div class="membre-tache-item ${retard ? 'retard' : ''}" onclick="fermerDetailMembre();ouvrirDetail(${t.id})">
                <div class="mt-head">
                    <div class="mt-ref">
                        ${retard ? '<i data-lucide="alert-circle" class="icon-retard"></i>' : ''}
                        ${escapeHtml(t.reference || '-')}
                    </div>
                    <div class="mt-badges">
                        <span class="badge badge-${t.statut}">${statutLabel(t.statut)}</span>
                        <span class="badge badge-${t.priorite}">${t.priorite}</span>
                    </div>
                </div>

                <div class="mt-titre">${escapeHtml(t.titre)}</div>

                ${t.description ? `<div class="mt-desc">${escapeHtml(t.description).substring(0, 150)}${t.description.length > 150 ? '...' : ''}</div>` : ''}

                <div class="mt-details">
                    ${t.categorie ? `<span class="mt-detail"><i data-lucide="tag"></i> ${escapeHtml(t.categorie)}</span>` : ''}
                    ${t.demandeur_nom ? `<span class="mt-detail"><i data-lucide="user"></i> ${escapeHtml(t.demandeur_nom)}</span>` : ''}
                    ${t.siege ? `<span class="mt-detail"><i data-lucide="map-pin"></i> ${escapeHtml(t.siege)}</span>` : ''}
                    ${t.service_concerne ? `<span class="mt-detail"><i data-lucide="briefcase"></i> ${escapeHtml(t.service_concerne)}</span>` : ''}
                    <span class="mt-detail ${retard ? 'texte-retard' : ''}"><i data-lucide="calendar"></i> ${echeance}</span>
                </div>

                <div class="mt-progress">
                    <div class="progress-bar"><span style="width:${t.avancement}%"></span></div>
                    <span class="progress-pct">${t.avancement}%</span>
                </div>
            </div>
        `;
    }).join('');

    body.innerHTML = `
        <div style="padding: 22px 26px;">
            ${statsBloc}
            <div class="membre-taches-list">
                ${tachesBloc}
            </div>
        </div>
    `;

    if (window.lucide) lucide.createIcons({ nodes: [modal] });
};

function fermerDetailMembre() {
    const m = document.getElementById('modal-membre-detail');
    if (m) m.classList.remove('open');
}

// ============================================
//  FILTRES — écouteurs
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    ['filtre-statut', 'filtre-priorite', 'filtre-categorie', 'filtre-assigne'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', chargerTaches);
    });

    const r = document.getElementById('filtre-recherche');
    if (r) {
        let timeout;
        r.addEventListener('input', () => {
            clearTimeout(timeout);
            timeout = setTimeout(chargerTaches, 300);
        });
    }

    const m = document.getElementById('filtre-mes');
    if (m) m.addEventListener('change', chargerTaches);

    if (document.getElementById('taches-container')) chargerTaches();
    if (document.getElementById('equipe-container')) chargerEquipe();

    if (window.lucide) lucide.createIcons();
});

function reinitialiserFiltres() {
    ['filtre-statut', 'filtre-priorite', 'filtre-categorie', 'filtre-assigne', 'filtre-recherche'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    const m = document.getElementById('filtre-mes');
    if (m) m.checked = false;
    chargerTaches();
}

// ============================================
//  FERMETURE MODALS
// ============================================
document.addEventListener('click', e => {
    if (e.target.classList && e.target.classList.contains('modal')) {
        e.target.classList.remove('open');
    }
});

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal.open').forEach(m => m.classList.remove('open'));
    }
});
// ============================================
//  PAGE VALIDATION (chef)
// ============================================
async function chargerValidation() {
    const container = document.getElementById('validation-container');
    if (!container) return;

    container.innerHTML = '<div class="loading">Chargement</div>';

    try {
        const data = await apiGet('taches_a_valider.php');
        afficherValidation(data);
    } catch (e) {
        console.error(e);
        container.innerHTML = '<div class="empty">Erreur de chargement.</div>';
    }
}

function afficherValidation(data) {
    const container = document.getElementById('validation-container');
    const compteur = document.getElementById('compteur-nb');

    if (compteur) compteur.textContent = data.total;

    if (!data.taches.length) {
        container.innerHTML = `
            <div class="validation-empty">
                <div class="validation-empty-icon">✅</div>
                <h3>Aucun ticket en attente</h3>
                <p>Tous les tickets sont à jour. Bon travail !</p>
            </div>`;
        return;
    }

    container.innerHTML = data.taches.map(carteValidation).join('');
    if (window.lucide) lucide.createIcons();
}

function carteValidation(t) {
    const retard = parseInt(t.en_retard) === 1;
    const joursRetard = parseInt(t.jours_retard) || 0;

    const descBloc = t.description
        ? '<p class="carte-validation-desc">' + escapeHtml(t.description) + '</p>'
        : '';

    const retardBloc = retard
        ? `<div class="alerte-retard">
               <i data-lucide="alert-triangle"></i>
               En retard de ${joursRetard} jour(s)
           </div>`
        : '';

    const dateCreation = t.date_creation
        ? new Date(t.date_creation).toLocaleDateString('fr-FR', {day: '2-digit', month: 'short', year: 'numeric'})
        : '-';

    const echeance = t.date_echeance
        ? new Date(t.date_echeance).toLocaleDateString('fr-FR', {day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'})
        : '-';

    return `
        <div class="carte-validation ${retard ? 'en-retard' : ''}">
            <div class="carte-validation-header">
                <div style="flex:1;">
                    <div class="carte-validation-ref">
                        ${retard ? '<i data-lucide="alert-circle" class="icon-retard"></i>' : ''}
                        ${escapeHtml(t.reference || '-')}
                    </div>
                    <div class="carte-validation-titre" onclick="ouvrirDetail(${t.id})">
                        ${escapeHtml(t.titre)}
                    </div>
                </div>
            </div>

            ${retardBloc}
            ${descBloc}

            <div class="carte-validation-badges">
                <span class="badge badge-${t.statut}">${statutLabel(t.statut)}</span>
                <span class="badge badge-${t.priorite}">${t.priorite}</span>
                ${t.categorie ? '<span class="badge badge-normale">' + escapeHtml(t.categorie) + '</span>' : ''}
            </div>

            <div class="carte-validation-meta">
                <div>
                    <strong>Technicien</strong>
                    <span>${escapeHtml(t.assigne_nom || 'Non assigné')}</span>
                </div>
                <div>
                    <strong>Service</strong>
                    <span>${escapeHtml(t.service_concerne || '-')}</span>
                </div>
                <div>
                    <strong>Créé le</strong>
                    <span>${dateCreation}</span>
                </div>
                <div>
                    <strong>Échéance</strong>
                    <span class="${retard ? 'texte-retard' : ''}">${echeance}</span>
                </div>
            </div>

            <div class="carte-validation-actions">
                <button class="btn btn-primary" onclick="validerTache(${t.id},'valider')">
                    <i data-lucide="check-circle-2"></i> Valider
                </button>
                <button class="btn btn-ghost" onclick="validerTache(${t.id},'refuser')">
                    <i data-lucide="x"></i> Refuser
                </button>
            </div>
        </div>
    `;
}

// Recharge la page de validation après une action
const _ancienneValiderTache = validerTache;
window.validerTache = async function(id, action) {
    let motif = '';
    if (action === 'refuser') {
        motif = await promptMotif('Motif du refus');
        if (!motif) return;
    }
    const res = await apiPost('tache_valider.php', {id, action, motif});
    if (res.success) {
        toast(action === 'valider' ? 'Ticket validé' : 'Ticket refusé', 'success');
        // Recharger la bonne page selon le contexte
        if (document.getElementById('validation-container')) chargerValidation();
        if (document.getElementById('tickets-tbody')) chargerTaches();
    } else {
        toast(res.error || 'Erreur', 'error');
    }
};

// Chargement au démarrage
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('validation-container')) chargerValidation();
});
// ============================================
//  PAGE STATISTIQUES (chef)
// ============================================
let chartChargeInstance = null;
let chartStatutInstance = null;
let chartPrioriteInstance = null;
let chartEvolutionInstance = null;

async function chargerStats() {
    if (!document.getElementById('stats-cards')) return;

    try {
        const data = await apiGet('stats_complet.php');
        afficherStats(data);
    } catch (e) {
        console.error('Erreur stats:', e);
        toast('Erreur de chargement des statistiques', 'error');
    }
}

function afficherStats(data) {
    // Cartes
    document.getElementById('stat-total').textContent = data.stats.total || 0;
    document.getElementById('stat-en-cours').textContent = data.stats.en_cours || 0;
    document.getElementById('stat-valide').textContent = data.stats.valide || 0;
    document.getElementById('stat-retard').textContent = data.stats.en_retard || 0;

    // Taux de complétion
    document.getElementById('taux-valeur').textContent = data.tauxCompletion + '%';
    document.getElementById('taux-progress').style.width = data.tauxCompletion + '%';

    // Graphiques
    dessinerChartCharge(data.charge);
    dessinerChartStatut(data.parStatut);
    dessinerChartPriorite(data.parPriorite);
    dessinerChartEvolution(data.evolution);

    // Top urgents
    afficherTopUrgents(data.topUrgents);

    if (window.lucide) lucide.createIcons();
}

// ---- Graphique charge par technicien ----
function dessinerChartCharge(charge) {
    const ctx = document.getElementById('chartCharge');
    if (!ctx) return;

    if (chartChargeInstance) chartChargeInstance.destroy();

    chartChargeInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: charge.map(c => c.nom),
            datasets: [
                {
                    label: 'En cours',
                    data: charge.map(c => parseInt(c.actives) || 0),
                    backgroundColor: '#2b6cb0',
                    borderRadius: 6
                },
                {
                    label: 'Terminées',
                    data: charge.map(c => parseInt(c.terminees) || 0),
                    backgroundColor: '#2f855a',
                    borderRadius: 6
                },
                {
                    label: 'En retard',
                    data: charge.map(c => parseInt(c.en_retard) || 0),
                    backgroundColor: '#9b2c2c',
                    borderRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            },
            scales: {
                x: { stacked: false, grid: { display: false } },
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });
}

// ---- Camembert statut ----
function dessinerChartStatut(parStatut) {
    const ctx = document.getElementById('chartStatut');
    if (!ctx) return;

    if (chartStatutInstance) chartStatutInstance.destroy();

    const labels = {
        'a_faire': 'À faire',
        'en_cours': 'En cours',
        'en_attente_validation': 'En attente',
        'valide': 'Validé'
    };
    const couleurs = {
        'a_faire': '#718096',
        'en_cours': '#2b6cb0',
        'en_attente_validation': '#b7791f',
        'valide': '#2f855a'
    };

    chartStatutInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: parStatut.map(s => labels[s.statut] || s.statut),
            datasets: [{
                data: parStatut.map(s => parseInt(s.nb)),
                backgroundColor: parStatut.map(s => couleurs[s.statut] || '#ccc'),
                borderWidth: 3,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            },
            cutout: '62%'
        }
    });
}

// ---- Camembert priorité ----
function dessinerChartPriorite(parPriorite) {
    const ctx = document.getElementById('chartPriorite');
    if (!ctx) return;

    if (chartPrioriteInstance) chartPrioriteInstance.destroy();

    const labels = {
        'urgente': 'Urgente',
        'haute': 'Haute',
        'normale': 'Normale',
        'basse': 'Basse'
    };
    const couleurs = {
        'urgente': '#9b2c2c',
        'haute': '#b7791f',
        'normale': '#2b6cb0',
        'basse': '#718096'
    };

    chartPrioriteInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: parPriorite.map(p => labels[p.priorite] || p.priorite),
            datasets: [{
                data: parPriorite.map(p => parseInt(p.nb)),
                backgroundColor: parPriorite.map(p => couleurs[p.priorite] || '#ccc'),
                borderWidth: 3,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            },
            cutout: '62%'
        }
    });
}

// ---- Graphique évolution ----
function dessinerChartEvolution(evolution) {
    const ctx = document.getElementById('chartEvolution');
    if (!ctx) return;

    if (chartEvolutionInstance) chartEvolutionInstance.destroy();

    chartEvolutionInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: evolution.map(e => {
                const d = new Date(e.jour);
                return d.toLocaleDateString('fr-FR', {day: '2-digit', month: 'short'});
            }),
            datasets: [{
                label: 'Tickets créés',
                data: evolution.map(e => parseInt(e.nb)),
                borderColor: '#1e3a5f',
                backgroundColor: 'rgba(30,58,95,.1)',
                tension: .35,
                fill: true,
                pointBackgroundColor: '#1e3a5f',
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: { grid: { display: false } },
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });
}

// ---- Top 5 urgents ----
function afficherTopUrgents(tickets) {
    const container = document.getElementById('top-urgents');
    if (!container) return;

    if (!tickets.length) {
        container.innerHTML = '<p class="empty">Aucun ticket urgent en cours.</p>';
        return;
    }

    container.innerHTML = tickets.map((t, i) => {
        const echeance = t.date_echeance
            ? new Date(t.date_echeance).toLocaleDateString('fr-FR', {day: '2-digit', month: 'short'})
            : '-';
        return `
            <div class="top-urgent-item" onclick="ouvrirDetail(${t.id})">
                <div class="top-urgent-rang">#${i + 1}</div>
                <div class="top-urgent-info">
                    <div class="top-urgent-ref">${escapeHtml(t.reference || '-')}</div>
                    <div class="top-urgent-titre">${escapeHtml(t.titre)}</div>
                    <div class="top-urgent-meta">
                        <span class="badge badge-${t.priorite}">${t.priorite}</span>
                        <span>👤 ${escapeHtml(t.assigne_nom || 'Non assigné')}</span>
                        <span>📅 ${echeance}</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    if (window.lucide) lucide.createIcons({ nodes: [container] });
}

// Chargement automatique
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('stats-cards')) chargerStats();
});
// ============================================
//  MODE SOMBRE
// ============================================
function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    const next = current === 'dark' ? 'light' : 'dark';

    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);

    // Recréer les icônes Lucide (lune / soleil)
    if (window.lucide) lucide.createIcons();

    // Petit toast
    toast(next === 'dark' ? 'Mode sombre activé' : 'Mode clair activé', 'info');
}

// Appliquer le thème au chargement
document.addEventListener('DOMContentLoaded', () => {
    const saved = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const theme = saved || (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);

    if (window.lucide) lucide.createIcons();
});
// ============================================
//  EXPORT PDF
// ============================================
function exporterPDF(e) {
    if (e) e.preventDefault();

    // Récupérer les filtres actifs
    const params = new URLSearchParams({
        statut:    document.getElementById('filtre-statut')?.value || '',
        priorite:  document.getElementById('filtre-priorite')?.value || '',
        categorie: document.getElementById('filtre-categorie')?.value || '',
        q:         document.getElementById('filtre-recherche')?.value || ''
    });

    // Ouvrir dans un nouvel onglet (téléchargement direct)
    window.location.href = 'api/export_pdf.php?' + params.toString();

    toast('Génération du PDF en cours...', 'info');
}
// ============================================
//  NOTIFICATIONS
// ============================================
let notifInterval = null;

async function chargerNotifications() {
    try {
        const data = await apiGet('notifications_list.php');
        const badge = document.getElementById('notif-count');
        if (badge) {
            if (data.non_lues > 0) {
                badge.textContent = data.non_lues > 99 ? '99+' : data.non_lues;
                badge.style.display = 'flex';
            } else {
                badge.style.display = 'none';
            }
        }
    } catch (e) {
        // Silencieux
    }
}

async function ouvrirNotifs() {
    const modal = document.getElementById('modal-notifs');
    const body = document.getElementById('notifs-body');
    if (!modal || !body) return;

    modal.classList.add('open');
    body.innerHTML = '<div class="loading">Chargement</div>';

    const data = await apiGet('notifications_list.php');

    if (!data.notifications.length) {
        body.innerHTML = '<div style="padding:40px;text-align:center;color:var(--muted);">Aucune notification.</div>';
        return;
    }

    const iconMap = {
        'assignation': 'user-plus',
        'desassignation': 'user-minus',
        'validation': 'check-circle-2',
        'refus': 'x-circle',
        'commentaire': 'message-square',
        'creation': 'plus-circle'
    };

    body.innerHTML = data.notifications.map(n => {
        const icon = iconMap[n.type] || 'bell';
        const date = new Date(n.date_creation).toLocaleString('fr-FR', {
            day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
        });
        return `
            <div class="notif-item ${n.lue == 0 ? 'non-lue' : ''}" onclick="ouvrirNotif(${n.id}, ${n.tache_id || 0})">
                <div class="notif-icon notif-${n.type}">
                    <i data-lucide="${icon}"></i>
                </div>
                <div class="notif-content">
                    <div class="notif-titre">${escapeHtml(n.titre)}</div>
                    <div class="notif-message">${escapeHtml(n.message || '')}</div>
                    <div class="notif-date">${date}</div>
                </div>
            </div>
        `;
    }).join('');

    if (window.lucide) lucide.createIcons({ nodes: [body] });
}

async function ouvrirNotif(id, tacheId) {
    await apiPost('notification_mark_read.php', { id });
    chargerNotifications();
    if (tacheId) {
        fermerNotifs();
        ouvrirDetail(tacheId);
    }
}

async function toutMarquerLu() {
    await apiPost('notification_mark_read.php', {});
    ouvrirNotifs();
    chargerNotifications();
}

function fermerNotifs() {
    const m = document.getElementById('modal-notifs');
    if (m) m.classList.remove('open');
}

// Polling toutes les 30 secondes
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('notif-count')) {
        chargerNotifications();
        notifInterval = setInterval(chargerNotifications, 30000);
    }
});
// ============================================
//  RÉASSIGNATION
// ============================================
async function ouvrirReassignation(id) {
    // Récupérer les users
    const users = await apiGet('users_list.php');
    const tache = await apiGet('tache_detail.php', { id });

    const modal = document.createElement('div');
    modal.className = 'modal open';
    modal.innerHTML = `
        <div class="modal-content" style="max-width:440px">
            <div class="modal-header">
                <h2>Réassigner le ticket</h2>
                <button class="modal-close" onclick="this.closest('.modal').remove()">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <div style="padding: 22px 26px;">
                <p style="margin-bottom: 14px; color: var(--text-soft); font-size: 13px;">
                    <strong>${escapeHtml(tache.tache.reference)}</strong> — ${escapeHtml(tache.tache.titre)}
                </p>

                <label>Nouveau technicien</label>
                <select id="reassign-select" style="width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:8px;font-family:inherit;font-size:14px;background:var(--bg);">
                    <option value="">— Non assigné —</option>
                    ${users.map(u => `
                        <option value="${u.id}" ${u.id == tache.tache.assigne_a_id ? 'selected' : ''}>
                            ${escapeHtml(u.nom)} ${u.id == tache.tache.assigne_a_id ? '(actuel)' : ''}
                        </option>
                    `).join('')}
                </select>

                <label style="margin-top:14px;">Motif (optionnel)</label>
                <textarea id="reassign-motif" rows="2" placeholder="Ex : Congé du technicien actuel..." style="width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:8px;font-family:inherit;font-size:14px;background:var(--bg);"></textarea>

                <div class="modal-actions">
                    <button class="btn btn-ghost" onclick="this.closest('.modal').remove()">Annuler</button>
                    <button class="btn btn-primary" onclick="confirmerReassignation(${id})">
                        <i data-lucide="check"></i> Réassigner
                    </button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    if (window.lucide) lucide.createIcons({ nodes: [modal] });
}

async function confirmerReassignation(id) {
    const select = document.getElementById('reassign-select');
    const motif = document.getElementById('reassign-motif').value.trim();
    const assigne = select.value || null;

    const res = await apiPost('tache_assign.php', {
        id,
        assigne_a_id: assigne,
        motif
    });

    if (res.success) {
        document.querySelectorAll('.modal.open').forEach(m => m.remove());
        toast('Ticket réassigné avec succès', 'success');
        if (document.getElementById('tickets-tbody')) chargerTaches();
        if (document.getElementById('equipe-container')) chargerEquipe();
    } else {
        toast(res.error || 'Erreur', 'error');
    }
}
// ============================================
//  MENUS DÉROULANTS
// ============================================
function toggleDropdown(btn) {
    const dropdown = btn.parentElement;
    
    // Optionnel : Fermer les autres menus quand on en ouvre un
    const allDropdowns = document.querySelectorAll('.nav-dropdown');
    allDropdowns.forEach(d => {
        if (d !== dropdown) d.classList.remove('open');
    });

    // Ouvrir / Fermer celui qui est cliqué
    dropdown.classList.toggle('open');
}
// Force le rechargement des icônes au démarrage
document.addEventListener('DOMContentLoaded', () => {
    if (window.lucide) {
        setTimeout(() => lucide.createIcons(), 100);
    }
});