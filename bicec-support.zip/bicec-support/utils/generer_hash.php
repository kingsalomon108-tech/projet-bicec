<?php
// À exécuter UNE FOIS pour générer des hash de mot de passe
// Accès : http://localhost/bicec-support/utils/generer_hash.php

$mots = ['admin123', 'membre123', 'salomon2024', 'chef2024'];
foreach ($mots as $m) {
    echo "<p><strong>$m</strong> → " . password_hash($m, PASSWORD_DEFAULT) . "</p>";
}
