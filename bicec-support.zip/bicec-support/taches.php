<?php
require_once 'config/db.php';
require_once 'includes/auth.php';
exiger_connexion();

$titre = 'Tickets';
$u = utilisateur_actuel();

if (est_chef()) {
    $users = $pdo->query("SELECT id, nom, role FROM utilisateurs WHERE actif=1 ORDER BY nom")->fetchAll();
} else {
    $users = [$u];
}

include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/bg.php';
?>

<div class="page-header">
    <h1>Gestion des tickets</h1>
    <button class="btn btn-accent" onclick="ouvrirModalTache()" style="margin-top: 8px;">
        <i data-lucide="plus"></i> Nouveau ticket
    </button>
</div>

<div class="filters filters-compact">
    <input type="text" id="filtre-recherche" placeholder="Rechercher (référence, titre)...">

    <select id="filtre-statut">
        <option value="">Tous les statuts</option>
        <option value="a_faire">À faire</option>
        <option value="en_cours">En cours</option>
        <option value="en_attente_validation">En attente</option>
        <option value="valide">Validé</option>
    </select>

    <select id="filtre-priorite">
        <option value="">Toutes priorités</option>
        <option value="urgente">Urgente</option>
        <option value="haute">Haute</option>
        <option value="normale">Normale</option>
        <option value="basse">Basse</option>
    </select>

    <select id="filtre-categorie">
        <option value="">Toutes catégories</option>
        <option value="informatique">Informatique</option>
        <option value="maintenance">Maintenance</option>
        <option value="client">Client</option>
        <option value="administratif">Administratif</option>
        <option value="autre">Autre</option>
    </select>

    <button class="btn btn-ghost btn-sm" onclick="reinitialiserFiltres()">
        <i data-lucide="rotate-ccw"></i> Réinitialiser
    </button>
</div>

<div class="table-container">
    <table class="table-tickets">
        <thead>
            <tr>
                <th>Référence</th>
                <th>Type</th>
                <th>Titre</th>
                <th>Catégorie</th>
                <th>Technicien</th>
                <th>Demandeur</th>
                <th>Priorité</th>
                <th>Statut</th>
                <th>Échéance</th>
                <th>Service</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="tickets-tbody">
            <tr>
                <td colspan="10" class="loading-cell">Chargement</td>
            </tr>
        </tbody>
    </table>
</div>

<div id="pagination" class="pagination"></div>

<div class="table-actions-bottom">
    <a href="#" class="btn btn-ghost" onclick="exporterPDF(event)">
        <i data-lucide="download"></i> Exporter PDF
    </a>
</div>
<!-- Modal Tâche -->
<div id="modal-tache" class="modal">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h2 id="modal-titre">Nouveau ticket</h2>
            <button class="modal-close" onclick="fermerModalTache()">
                <i data-lucide="x"></i>
            </button>
        </div>
        <form id="form-tache" onsubmit="soumettreTache(event)" enctype="multipart/form-data">
            <input type="hidden" id="tache-id">

            <label>Titre *</label>
            <input type="text" id="tache-titre" required>

            <label>Description</label>
            <textarea id="tache-description" rows="3"></textarea>

            <div class="form-row">
                <div>
                    <label>Type</label>
                    <select id="tache-type">
                        <option value="incident">Incident</option>
                        <option value="demande">Demande</option>
                        <option value="probleme">Problème</option>
                        <option value="changement">Changement</option>
                    </select>
                </div>
                <div>
                    <label>Catégorie</label>
                    <select id="tache-categorie" onchange="majerSla()">
                        <option value="informatique">Informatique</option>
                        <option value="maintenance">Maintenance</option>
                        <option value="client">Client</option>
                        <option value="administratif">Administratif</option>
                        <option value="autre" selected>Autre</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div>
                    <label>Priorité</label>
                    <select id="tache-priorite" onchange="majerSla()">
                        <option value="basse">Basse</option>
                        <option value="normale" selected>Normale</option>
                        <option value="haute">Haute</option>
                        <option value="urgente">Urgente</option>
                    </select>
                </div>
                <div>
                    <label>Service concerné</label>
                    <input type="text" id="tache-service">
                </div>
            </div>
<div class="form-row">
    <div>
        <label>Siège / Agence</label>
        <input type="text" id="tache-siege" placeholder="Ex : Siège central, Agence Douala...">
    </div>
    <div>
        <label>Service demandeur</label>
        <input type="text" id="tache-demandeur-service" placeholder="Ex : Comptabilité, RH...">
    </div>
</div>

<label>Nom du demandeur</label>
<input type="text" id="tache-demandeur-nom" placeholder="Ex : M. Kamga Jean">
            <div class="sla-info" id="sla-info">
                <i data-lucide="clock"></i>
                <span id="sla-text">Échéance calculée automatiquement selon le SLA</span>
            </div>

            <?php if (est_chef()): ?>
                <label>Assigner à</label>
                <select id="tache-assigne">
                    <option value="">— Non assigné —</option>
                    <?php foreach ($users as $usr): ?>
                        <option value="<?= $usr['id'] ?>"><?= htmlspecialchars($usr['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            <?php else: ?>
                <input type="hidden" id="tache-assigne" value="<?= $u['id'] ?>">
            <?php endif; ?>

            <label>Pièces jointes</label>
            <input type="file" id="tache-fichiers" multiple
                accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.gif,.txt,.zip"
                class="file-input">

            <div class="modal-actions">
                <button type="button" class="btn btn-ghost" onclick="fermerModalTache()">Annuler</button>
                <button type="submit" class="btn btn-primary">
                    <i data-lucide="save"></i> Enregistrer
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Détail -->
<div id="modal-detail" class="modal">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h2>Détail du ticket</h2>
            <button class="modal-close" onclick="fermerModalDetail()">
                <i data-lucide="x"></i>
            </button>
        </div>
        <div id="detail-body"></div>
    </div>
</div>

<?php include 'includes/bg-end.php'; ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof chargerTaches === 'function') {
            chargerTaches(1);
        }
    });
</script>
<?php include 'includes/footer.php'; ?>