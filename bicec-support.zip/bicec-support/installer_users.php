<?php
require_once 'config/db.php';

// Mot de passe en clair
$users = [
    ['Chef Support',  'chef@bicec.cm',    'admin123',  'chef'],
    ['Salomon',       'salomon@bicec.cm', 'membre123', 'membre'],
];

// On supprime les anciens pour repartir propre
$pdo->exec("DELETE FROM utilisateurs");

$stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, email, mot_de_passe, role) VALUES (?, ?, ?, ?)");

foreach ($users as $u) {
    $hash = password_hash($u[2], PASSWORD_DEFAULT);
    $stmt->execute([$u[0], $u[1], $hash, $u[3]]);
    echo "✅ Utilisateur créé : <strong>{$u[1]}</strong> / mot de passe : <strong>{$u[2]}</strong><br>";
}

echo "<hr><p>Tout est prêt ! Tu peux maintenant te connecter sur <a href='login.php'>login.php</a></p>";