<?php
require_once 'config/db.php';
require_once 'includes/auth.php';
exiger_connexion();

$titre = 'Tableau de bord';
$u = utilisateur_actuel();
$isChef = est_chef();

// ============================================
//  STATISTIQUES
// ============================================
if ($isChef) {
    $stats = $pdo->query("
        SELECT 
            COUNT(*) AS total,
            SUM(statut = 'valide') AS valide,
            SUM(statut = 'en_cours' AND motif_refus IS NOT NULL) AS refusees,
            SUM(statut = 'en_attente_validation') AS en_attente,
            SUM(date_echeance < NOW() AND statut NOT IN ('valide')) AS en_retard
        FROM taches
    ")->fetch();
} else {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) AS total,
            SUM(statut = 'en_cours') AS en_cours,
            SUM(statut IN ('en_attente_validation','valide')) AS termines,
            SUM(date_echeance < NOW() AND statut NOT IN ('valide')) AS en_retard
        FROM taches 
        WHERE assigne_a_id = ?
    ");
    $stmt->execute([$u['id']]);
    $stats = $stmt->fetch();
}

// ============================================
//  TÂCHES RÉCENTES
// ============================================
if ($isChef) {
    $recentes = $pdo->query("
        SELECT t.*, u.nom AS assigne_nom, c.nom AS createur_nom
        FROM taches t 
        LEFT JOIN utilisateurs u ON u.id = t.assigne_a_id
        LEFT JOIN utilisateurs c ON c.id = t.createur_id
        ORDER BY t.date_creation DESC 
        LIMIT 5
    ")->fetchAll();
} else {
    $stmt = $pdo->prepare("
        SELECT t.*, u.nom AS assigne_nom, c.nom AS createur_nom
        FROM taches t 
        LEFT JOIN utilisateurs u ON u.id = t.assigne_a_id
        LEFT JOIN utilisateurs c ON c.id = t.createur_id
        WHERE t.assigne_a_id = ? OR t.createur_id = ?
        ORDER BY t.date_creation DESC 
        LIMIT 5
    ");
    $stmt->execute([$u['id'], $u['id']]);
    $recentes = $stmt->fetchAll();
}

include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/bg.php';
?>

<!-- ============================================
     HERO
     ============================================ -->
<div class="dashboard-hero">
    <div class="hero-content">
        <div class="hero-avatar">
            <?= strtoupper(substr($u['nom'], 0, 1)) ?>
        </div>
        <div class="hero-text">
            <div class="hero-greeting">Bienvenue,</div>
            <h1 class="hero-name"><?= htmlspecialchars($u['nom']) ?></h1>
            <div class="hero-role">
                <i data-lucide="<?= $isChef ? 'shield-check' : 'user' ?>"></i>
                <?= $isChef ? 'Chef d\'équipe' : 'Technicien support' ?>
                <span class="hero-sep">·</span>
                <span><?= date('d/m/Y') ?></span>
            </div>
        </div>
    </div>
    <div class="hero-actions">
        <div class="hero-badge">
            <i data-lucide="activity"></i>
            <span><?= $isChef ? 'Vue équipe' : 'Mes activités' ?></span>
        </div>
    </div>
</div>

<!-- ============================================
     STATISTIQUES
     ============================================ -->
<div class="stats-grid">
    <?php if ($isChef): ?>
        <div class="stat-card success">
            <div class="stat-value"><?= (int)($stats['valide'] ?? 0) ?></div>
            <div class="stat-label">Tâches validées</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= (int)($stats['refusees'] ?? 0) ?></div>
            <div class="stat-label">Tâches refusées</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= (int)($stats['en_attente'] ?? 0) ?></div>
            <div class="stat-label">En attente validation</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?= (int)($stats['total'] ?? 0) ?></div>
            <div class="stat-label">Total terminées</div>
        </div>
    <?php else: ?>
        <div class="stat-card">
            <div class="stat-value"><?= (int)($stats['total'] ?? 0) ?></div>
            <div class="stat-label">Tâches assignées</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= (int)($stats['en_cours'] ?? 0) ?></div>
            <div class="stat-label">En cours</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= (int)($stats['termines'] ?? 0) ?></div>
            <div class="stat-label">Terminées</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= (int)($stats['en_retard'] ?? 0) ?></div>
            <div class="stat-label">En retard</div>
        </div>
    <?php endif; ?>
</div>

<!-- ============================================
     TÂCHES RÉCENTES (CLIQUABLES)
     ============================================ -->
<h2>Tâches récentes</h2>
<div class="task-list">
    <?php if (!$recentes): ?>
        <p class="empty">Aucune tâche pour le moment.</p>
    <?php else: foreach ($recentes as $t): 
        $enRetard = $t['date_echeance'] && strtotime($t['date_echeance']) < time() && $t['statut'] !== 'valide';
    ?>
        <div class="task-item <?= $enRetard ? 'task-retard' : '' ?>" 
             onclick="ouvrirDetail(<?= (int)$t['id'] ?>)" 
             style="cursor:pointer;"
             title="Cliquer pour voir le détail">
            <div class="task-main">
                <div class="task-title-row">
                    <span class="task-ref"><?= htmlspecialchars($t['reference'] ?? '-') ?></span>
                    <?php if ($enRetard): ?>
                        <span class="task-alert">
                            <i data-lucide="alert-circle"></i> En retard
                        </span>
                    <?php endif; ?>
                </div>
                <div class="task-title"><?= htmlspecialchars($t['titre']) ?></div>
                <div class="task-details">
                    <?php if (!empty($t['categorie'])): ?>
                        <span class="task-detail">
                            <i data-lucide="tag"></i>
                            <?= htmlspecialchars($t['categorie']) ?>
                        </span>
                    <?php endif; ?>
                    <?php if (!empty($t['demandeur_nom'])): ?>
                        <span class="task-detail">
                            <i data-lucide="user"></i>
                            <?= htmlspecialchars($t['demandeur_nom']) ?>
                        </span>
                    <?php endif; ?>
                    <?php if (!empty($t['siege'])): ?>
                        <span class="task-detail">
                            <i data-lucide="map-pin"></i>
                            <?= htmlspecialchars($t['siege']) ?>
                        </span>
                    <?php endif; ?>
                    <?php if (!empty($t['date_echeance'])): ?>
                        <span class="task-detail">
                            <i data-lucide="calendar"></i>
                            Échéance : <?= date('d/m/Y H:i', strtotime($t['date_echeance'])) ?>
                        </span>
                    <?php endif; ?>
                    <?php if (!empty($t['assigne_nom'])): ?>
                        <span class="task-detail">
                            <i data-lucide="wrench"></i>
                            <?= htmlspecialchars($t['assigne_nom']) ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="task-meta">
                <span class="badge badge-<?= $t['statut'] ?>"><?= $t['statut'] ?></span>
                <span class="badge badge-<?= $t['priorite'] ?>"><?= $t['priorite'] ?></span>
                <div class="task-progress">
                    <div class="progress-bar"><span style="width:<?= (int)$t['avancement'] ?>%"></span></div>
                    <span class="progress-pct"><?= (int)$t['avancement'] ?>%</span>
                </div>
            </div>
        </div>
    <?php endforeach; endif; ?>
</div>

<!-- ============================================
     ACCÈS RAPIDE
     ============================================ -->
<h2>Accès rapide</h2>
<div class="quick-access">
    <a href="taches.php" class="quick-card">
        <div class="quick-icon quick-icon-blue">
            <i data-lucide="list-checks"></i>
        </div>
        <div class="quick-text">
            <div class="quick-title">Tâches</div>
            <div class="quick-sub">Gérer tous les tickets</div>
        </div>
        <i data-lucide="chevron-right" class="quick-arrow"></i>
    </a>

    <a href="equipe.php" class="quick-card">
        <div class="quick-icon quick-icon-green">
            <i data-lucide="users"></i>
        </div>
        <div class="quick-text">
            <div class="quick-title">Équipe</div>
            <div class="quick-sub">Voir les membres</div>
        </div>
        <i data-lucide="chevron-right" class="quick-arrow"></i>
    </a>

    <?php if ($isChef): ?>
    <a href="validation.php" class="quick-card">
        <div class="quick-icon quick-icon-orange">
            <i data-lucide="check-circle-2"></i>
        </div>
        <div class="quick-text">
            <div class="quick-title">Validation</div>
            <div class="quick-sub">Tickets à valider</div>
        </div>
        <i data-lucide="chevron-right" class="quick-arrow"></i>
    </a>

    <a href="statistiques.php" class="quick-card">
        <div class="quick-icon quick-icon-purple">
            <i data-lucide="bar-chart-3"></i>
        </div>
        <div class="quick-text">
            <div class="quick-title">Statistiques</div>
            <div class="quick-sub">Voir les graphiques</div>
        </div>
        <i data-lucide="chevron-right" class="quick-arrow"></i>
    </a>
    <?php endif; ?>
</div>

<!-- ============================================
     MODAL DÉTAIL (pour les tâches récentes cliquables)
     ============================================ -->
<div id="modal-detail" class="modal">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h2>Détail du ticket</h2>
            <button class="modal-close" onclick="fermerModalDetail()">
                <i data-lucide="x"></i>
            </button>
        </div>
        <div id="detail-body"></div>
    </div>
</div>

<?php include 'includes/bg-end.php'; ?>
<?php include 'includes/footer.php'; ?>