<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirige vers login si non connecté
function exiger_connexion() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

// Vérifie si l'utilisateur est chef
function est_chef() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'chef';
}

// Exige le rôle chef
function exiger_chef() {
    exiger_connexion();
    if (!est_chef()) {
        http_response_code(403);
        die("Accès refusé : réservé au chef d'équipe.");
    }
}

// Retourne les infos de l'utilisateur connecté
function utilisateur_actuel() {
    return [
        'id'   => $_SESSION['user_id'] ?? null,
        'nom'  => $_SESSION['nom'] ?? '',
        'role' => $_SESSION['role'] ?? ''
    ];
}