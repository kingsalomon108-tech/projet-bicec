<?php
/**
 * Affiche l'arrière-plan BICEC (image + wrapper)
 * À inclure juste après includes/sidebar.php sur chaque page
 */
?>
<div class="dashboard-bg" aria-hidden="true"></div>
<div class="dashboard-wrapper">