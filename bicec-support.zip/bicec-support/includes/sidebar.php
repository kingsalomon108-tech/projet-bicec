<?php $u = utilisateur_actuel(); ?>
<aside class="sidebar">
    <div class="brand">
        <div class="brand-logo">
            <img src="assets/img/logo-bicec.png" alt="BICEC">
        </div>
        <div class="brand-text">
            <span class="brand-name">BICEC</span>
            <span class="brand-sub">Support</span>
        </div>
    </div>

    <nav>
        <a href="dashboard.php" class="nav-item">
            <i data-lucide="layout-dashboard"></i><span>Tableau de bord</span>
        </a>
        <a href="taches.php" class="nav-item">
            <i data-lucide="list-checks"></i><span>Tâches</span>
        </a>
        <a href="equipe.php" class="nav-item">
            <i data-lucide="users"></i><span>Équipe</span>
        </a>

        <?php if (est_chef()): ?>
            <div class="separator">Chef d'équipe</div>
            <a href="validation.php" class="nav-item">
                <i data-lucide="check-circle-2"></i><span>Validation</span>
            </a>
            <a href="statistiques.php" class="nav-item">
                <i data-lucide="bar-chart-3"></i><span>Statistiques</span>
            </a>
        <?php endif; ?>
    </nav>

    <div class="user-info">
        <div class="user-avatar"><?= strtoupper(substr($u['nom'], 0, 1)) ?></div>
        <div class="user-details">
            <div class="user-name"><?= htmlspecialchars($u['nom']) ?></div>
            <div class="user-role"><?= $u['role'] === 'chef' ? 'Chef d\'équipe' : 'Membre' ?></div>
        </div>
        
        <div class="notif-bell" onclick="ouvrirNotifs()" title="Notifications">
            <i data-lucide="bell"></i>
            <span class="notif-badge" id="notif-count" style="display:none;">0</span>
        </div>

        <button class="btn-theme" onclick="toggleTheme()" title="Changer de thème">
            <i data-lucide="moon" class="icon-moon"></i>
            <i data-lucide="sun" class="icon-sun"></i>
        </button>
        <a href="logout.php" class="btn-logout" title="Déconnexion">
            <i data-lucide="log-out"></i>
        </a>
    </div>
</aside>
<main class="content">