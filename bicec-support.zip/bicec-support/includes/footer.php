</main>
</div><!-- .app -->
<script>
    window.ROLE = "<?= $_SESSION['role'] ?? '' ?>";
    window.USER = {
        id: <?= (int)($_SESSION['user_id'] ?? 0) ?>,
        nom: "<?= htmlspecialchars($_SESSION['nom'] ?? '') ?>"
    };
</script>
<script src="assets/js/app.js"></script>
<script>
    if (window.lucide) lucide.createIcons();
</script>
<!-- Modal Notifications -->
<div id="modal-notifs" class="modal">
    <div class="modal-content" style="max-width:480px;">
        <div class="modal-header">
            <h2>
                <i data-lucide="bell"></i> Notifications
            </h2>
            <button class="modal-close" onclick="fermerNotifs()">
                <i data-lucide="x"></i>
            </button>
        </div>
        <div id="notifs-body" style="padding: 10px 0; max-height: 60vh; overflow-y: auto;">
            <div class="loading">Chargement</div>
        </div>
        <div style="padding: 12px 20px; border-top: 1px solid var(--border); text-align: center;">
            <button class="btn btn-ghost btn-sm" onclick="toutMarquerLu()">
                <i data-lucide="check-check"></i> Tout marquer comme lu
            </button>
        </div>
    </div>
</div>
</body>
</html>