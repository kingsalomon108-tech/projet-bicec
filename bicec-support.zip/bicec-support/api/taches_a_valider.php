<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_chef();

header('Content-Type: application/json');

try {
    $sql = "SELECT t.*, 
                   u.nom AS assigne_nom,
                   c.nom AS createur_nom,
                   DATEDIFF(NOW(), t.date_echeance) AS jours_retard,
                   CASE 
                       WHEN t.date_echeance IS NOT NULL 
                            AND t.date_echeance < NOW() 
                       THEN 1 ELSE 0 
                   END AS en_retard
            FROM taches t
            LEFT JOIN utilisateurs u ON u.id = t.assigne_a_id
            LEFT JOIN utilisateurs c ON c.id = t.createur_id
            WHERE t.statut = 'en_attente_validation'
            ORDER BY 
                en_retard DESC,
                FIELD(t.priorite, 'urgente','haute','normale','basse'),
                t.date_creation ASC";

    $taches = $pdo->query($sql)->fetchAll();

    echo json_encode([
        'taches' => $taches,
        'total'  => count($taches)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur SQL : ' . $e->getMessage()]);
}