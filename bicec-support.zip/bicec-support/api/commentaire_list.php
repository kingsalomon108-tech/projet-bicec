<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$tache_id = (int)($_GET['tache_id'] ?? 0);
if (!$tache_id) { http_response_code(400); echo json_encode(['error'=>'ID manquant']); exit; }

$stmt = $pdo->prepare("SELECT c.*, u.nom AS auteur
    FROM commentaires c
    LEFT JOIN utilisateurs u ON u.id = c.utilisateur_id
    WHERE c.tache_id = ?
    ORDER BY c.date_creation ASC");
$stmt->execute([$tache_id]);

echo json_encode($stmt->fetchAll());