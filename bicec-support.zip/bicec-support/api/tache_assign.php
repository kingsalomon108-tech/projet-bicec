<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/notification_add.php';
exiger_chef();

header('Content-Type: application/json');

$u = utilisateur_actuel();
$data = json_decode(file_get_contents('php://input'), true);
$id         = (int)($data['id'] ?? 0);
$assigne    = !empty($data['assigne_a_id']) ? (int)$data['assigne_a_id'] : null;
$motif      = trim($data['motif'] ?? '');

if (!$id) { http_response_code(400); echo json_encode(['error'=>'ID manquant']); exit; }

// Récupérer la tâche
$stmt = $pdo->prepare("SELECT * FROM taches WHERE id = ?");
$stmt->execute([$id]);
$tache = $stmt->fetch();
if (!$tache) { http_response_code(404); echo json_encode(['error'=>'Tâche introuvable']); exit; }

$ancienAssigne = $tache['assigne_a_id'];

try {
    $pdo->beginTransaction();

    // Mettre à jour
    $pdo->prepare("UPDATE taches SET assigne_a_id = ? WHERE id = ?")
        ->execute([$assigne, $id]);

    // Historique
    $pdo->prepare("INSERT INTO historique (tache_id, utilisateur_id, action, ancienne_valeur, nouvelle_valeur)
                   VALUES (?, ?, 'réassignation', ?, ?)")
        ->execute([$id, $u['id'], $ancienAssigne, $assigne]);

    // Table réassignations
    $pdo->prepare("INSERT INTO reassignations (tache_id, ancien_technicien_id, nouveau_technicien_id, modifie_par, motif)
                   VALUES (?, ?, ?, ?, ?)")
        ->execute([$id, $ancienAssigne, $assigne, $u['id'], $motif]);

    // Notification au nouveau technicien
    if ($assigne && $assigne != $ancienAssigne) {
        creerNotification(
            $pdo,
            $assigne,
            'assignation',
            'Nouveau ticket assigné',
            'Vous avez été assigné au ticket ' . ($tache['reference'] ?? '') . ' : ' . $tache['titre'],
            $id
        );
    }

    // Notification à l'ancien technicien (si différent)
    if ($ancienAssigne && $ancienAssigne != $assigne && $ancienAssigne != $u['id']) {
        creerNotification(
            $pdo,
            $ancienAssigne,
            'desassignation',
            'Ticket réassigné',
            'Le ticket ' . ($tache['reference'] ?? '') . ' a été réassigné à un autre technicien.',
            $id
        );
    }

    $pdo->commit();
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}