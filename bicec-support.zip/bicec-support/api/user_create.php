<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_chef();

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$nom   = trim($data['nom'] ?? '');
$email = trim($data['email'] ?? '');
$mdp   = $data['mot_de_passe'] ?? '';
$role  = $data['role'] ?? 'membre';

// Validations
if (!$nom || !$email || !$mdp) {
    http_response_code(400);
    echo json_encode(['error' => 'Tous les champs sont obligatoires.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email invalide.']);
    exit;
}

if (strlen($mdp) < 6) {
    http_response_code(400);
    echo json_encode(['error' => 'Le mot de passe doit faire au moins 6 caractères.']);
    exit;
}

if (!in_array($role, ['membre', 'chef'])) {
    $role = 'membre';
}

try {
    // Vérifier si l'email existe déjà
    $stmt = $pdo->prepare("SELECT id FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Cet email est déjà utilisé.']);
        exit;
    }

    // Hasher le mot de passe
    $hash = password_hash($mdp, PASSWORD_DEFAULT);

    // Insertion
    $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, email, mot_de_passe, role, actif)
                           VALUES (?, ?, ?, ?, 1)");
    $stmt->execute([$nom, $email, $hash, $role]);

    $id = $pdo->lastInsertId();

    echo json_encode([
        'success' => true,
        'id'      => $id,
        'message' => 'Utilisateur créé avec succès.'
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur : ' . $e->getMessage()]);
}