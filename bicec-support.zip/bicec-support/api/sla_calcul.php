<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$categorie = $_GET['categorie'] ?? 'autre';
$priorite  = $_GET['priorite']  ?? 'normale';

$stmt = $pdo->prepare("SELECT heures FROM sla_config WHERE categorie = ? AND priorite = ?");
$stmt->execute([$categorie, $priorite]);
$sla = $stmt->fetch();

$heures = $sla ? (int)$sla['heures'] : 48;

$dateEcheance = new DateTime();
$dateEcheance->add(new DateInterval("PT{$heures}H"));

echo json_encode([
    'heures'         => $heures,
    'date_echeance'  => $dateEcheance->format('Y-m-d H:i:s'),
    'date_affichage' => $dateEcheance->format('d/m/Y H:i')
]);