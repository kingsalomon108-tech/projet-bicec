<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();
$tache_id = (int)($_POST['tache_id'] ?? 0);
if (!$tache_id) { http_response_code(400); echo json_encode(['error'=>'ID tâche manquant']); exit; }

if (empty($_FILES['fichier'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Aucun fichier']);
    exit;
}

$f = $_FILES['fichier'];
if ($f['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['error' => 'Erreur upload']);
    exit;
}

$nomOrig = basename($f['name']);
$ext     = strtolower(pathinfo($nomOrig, PATHINFO_EXTENSION));
$allowed = ['pdf','doc','docx','xls','xlsx','jpg','jpeg','png','gif','txt','zip'];

if (!in_array($ext, $allowed)) {
    http_response_code(400);
    echo json_encode(['error' => 'Type de fichier non autorisé']);
    exit;
}
if ($f['size'] > 10 * 1024 * 1024) {
    http_response_code(400);
    echo json_encode(['error' => 'Fichier trop volumineux (max 10 Mo)']);
    exit;
}

$uploadDir = __DIR__ . '/../uploads/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

$nouveauNom = uniqid('pj_', true) . '.' . $ext;
$cheminFull = $uploadDir . $nouveauNom;

if (move_uploaded_file($f['tmp_name'], $cheminFull)) {
    $pdo->prepare("INSERT INTO pieces_jointes (tache_id, utilisateur_id, nom_fichier, chemin, type_mime, taille)
                   VALUES (?, ?, ?, ?, ?, ?)")
        ->execute([$tache_id, $u['id'], $nomOrig, 'uploads/' . $nouveauNom, $f['type'], $f['size']]);
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur de sauvegarde']);
}