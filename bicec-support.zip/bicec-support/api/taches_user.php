<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$user_id = (int)($_GET['id'] ?? 0);
if (!$user_id) { http_response_code(400); echo json_encode(['error'=>'ID manquant']); exit; }

$stmt = $pdo->prepare("SELECT t.*, u.nom AS assigne_nom
    FROM taches t
    LEFT JOIN utilisateurs u ON u.id = t.assigne_a_id
    WHERE t.assigne_a_id = ?
    ORDER BY 
        FIELD(t.priorite, 'urgente','haute','normale','basse'),
        t.date_creation DESC");
$stmt->execute([$user_id]);
echo json_encode($stmt->fetchAll());