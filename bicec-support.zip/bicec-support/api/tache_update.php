<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();

$id = (int)($_POST['id'] ?? 0);
if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'ID manquant']);
    exit;
}

// Vérifier que la tâche existe
$stmt = $pdo->prepare("SELECT * FROM taches WHERE id = ?");
$stmt->execute([$id]);
$tache = $stmt->fetch();
if (!$tache) {
    http_response_code(404);
    echo json_encode(['error' => 'Tâche introuvable']);
    exit;
}

// 🔒 Un membre ne peut modifier que ses propres tâches
if ($u['role'] !== 'chef' 
    && $tache['assigne_a_id'] != $u['id'] 
    && $tache['createur_id'] != $u['id']) {
    http_response_code(403);
    echo json_encode(['error' => 'Vous ne pouvez modifier que vos tâches.']);
    exit;
}

$titre = trim($_POST['titre'] ?? '');
if ($titre === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Le titre est obligatoire.']);
    exit;
}

$description = trim($_POST['description'] ?? '');
$categorie   = $_POST['categorie'] ?? 'autre';
$priorite    = $_POST['priorite'] ?? 'normale';
$service     = trim($_POST['service_concerne'] ?? '');
$echeance    = !empty($_POST['date_echeance']) ? $_POST['date_echeance'] : null;
$assigne     = !empty($_POST['assigne_a_id']) ? (int)$_POST['assigne_a_id'] : null;
$siege            = trim($_POST['siege'] ?? '');
$demandeurNom     = trim($_POST['demandeur_nom'] ?? '');
$demandeurService = trim($_POST['demandeur_service'] ?? '');
try {
    $pdo->beginTransaction();

    // Mise à jour de la tâche
$stmt = $pdo->prepare("UPDATE taches 
    SET titre = ?, description = ?, categorie = ?, service_concerne = ?, 
        siege = ?, demandeur_nom = ?, demandeur_service = ?,
        priorite = ?, date_echeance = ?, assigne_a_id = ?
    WHERE id = ?");
$stmt->execute([
    $titre, $description, $categorie, $service,
    $siege, $demandeurNom, $demandeurService,
    $priorite, $echeance, $assigne, $id
]);
    // Historique
    $pdo->prepare("INSERT INTO historique (tache_id, utilisateur_id, action, nouvelle_valeur)
                   VALUES (?, ?, 'modification', ?)")
        ->execute([$id, $u['id'], $titre]);

    // Upload de nouvelles pièces jointes (si présentes)
    if (!empty($_FILES['fichiers']['name'][0])) {
        $uploadDir = __DIR__ . '/../uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $nb = count($_FILES['fichiers']['name']);
        for ($i = 0; $i < $nb; $i++) {
            if ($_FILES['fichiers']['error'][$i] !== UPLOAD_ERR_OK) continue;

            $nomOrig = basename($_FILES['fichiers']['name'][$i]);
            $ext     = strtolower(pathinfo($nomOrig, PATHINFO_EXTENSION));
            $allowed = ['pdf','doc','docx','xls','xlsx','jpg','jpeg','png','gif','txt','zip'];

            if (!in_array($ext, $allowed)) continue;
            if ($_FILES['fichiers']['size'][$i] > 10 * 1024 * 1024) continue;

            $nouveauNom = uniqid('pj_', true) . '.' . $ext;
            $cheminFull = $uploadDir . $nouveauNom;

            if (move_uploaded_file($_FILES['fichiers']['tmp_name'][$i], $cheminFull)) {
                $pdo->prepare("INSERT INTO pieces_jointes 
                    (tache_id, utilisateur_id, nom_fichier, chemin, type_mime, taille)
                    VALUES (?, ?, ?, ?, ?, ?)")
                    ->execute([
                        $id,
                        $u['id'],
                        $nomOrig,
                        'uploads/' . $nouveauNom,
                        $_FILES['fichiers']['type'][$i],
                        $_FILES['fichiers']['size'][$i]
                    ]);
            }
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Erreur : ' . $e->getMessage()]);
}