<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();
$page     = max(1, (int)($_GET['page'] ?? 1));
$parPage  = 20;
$offset   = ($page - 1) * $parPage;

$statut    = $_GET['statut']    ?? '';
$priorite  = $_GET['priorite']  ?? '';
$categorie = $_GET['categorie'] ?? '';
$recherche = $_GET['q']         ?? '';

$where = "WHERE 1=1";
$params = [];

// 🔒 Confidentialité stricte : un technicien ne voit QUE ses tickets
if ($u['role'] !== 'chef') {
    $where .= " AND t.assigne_a_id = ?";
    $params[] = $u['id'];
}

if ($statut)    { $where .= " AND t.statut = ?";    $params[] = $statut; }
if ($priorite)  { $where .= " AND t.priorite = ?";  $params[] = $priorite; }
if ($categorie) { $where .= " AND t.categorie = ?"; $params[] = $categorie; }
if ($recherche) { 
    $where .= " AND (t.titre LIKE ? OR t.reference LIKE ?)"; 
    $params[] = "%$recherche%";
    $params[] = "%$recherche%";
}

try {
    // Compter le total
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM taches t $where");
    $stmt->execute($params);
    $total = (int)$stmt->fetchColumn();

    // Récupérer la page
    $sql = "SELECT t.*, 
                   u.nom AS assigne_nom,
                   c.nom AS createur_nom,
                   CASE 
                       WHEN t.date_echeance IS NOT NULL 
                            AND t.date_echeance < NOW() 
                            AND t.statut NOT IN ('valide') 
                       THEN 1 ELSE 0 
                   END AS en_retard
            FROM taches t
            LEFT JOIN utilisateurs u ON u.id = t.assigne_a_id
            LEFT JOIN utilisateurs c ON c.id = t.createur_id
            $where
            ORDER BY 
                en_retard DESC,
                FIELD(t.priorite, 'urgente','haute','normale','basse'),
                t.date_creation DESC
            LIMIT $parPage OFFSET $offset";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $taches = $stmt->fetchAll();

    echo json_encode([
        'taches'       => $taches,
        'total'        => $total,
        'page'         => $page,
        'par_page'     => $parPage,
        'total_pages'  => (int)ceil($total / $parPage)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur SQL : ' . $e->getMessage()]);
}