<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();

// Récupération des données
$titre             = trim($_POST['titre'] ?? '');
$description       = trim($_POST['description'] ?? '');
$type              = $_POST['type_ticket'] ?? 'incident';
$categorie         = $_POST['categorie'] ?? 'autre';
$priorite          = $_POST['priorite'] ?? 'normale';
$service           = trim($_POST['service_concerne'] ?? '');
$siege             = trim($_POST['siege'] ?? '');
$demandeurNom      = trim($_POST['demandeur_nom'] ?? '');
$demandeurService  = trim($_POST['demandeur_service'] ?? '');
$echeance          = !empty($_POST['date_echeance']) ? $_POST['date_echeance'] : null;
$assigne           = !empty($_POST['assigne_a_id']) ? (int)$_POST['assigne_a_id'] : null;

// Validation
if ($titre === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Le titre est obligatoire.']);
    exit;
}

$typesValides = ['incident', 'demande', 'probleme', 'changement'];
if (!in_array($type, $typesValides)) $type = 'incident';

$categoriesValides = ['informatique', 'maintenance', 'client', 'administratif', 'autre'];
if (!in_array($categorie, $categoriesValides)) $categorie = 'autre';

$prioritesValides = ['basse', 'normale', 'haute', 'urgente'];
if (!in_array($priorite, $prioritesValides)) $priorite = 'normale';

try {
    $pdo->beginTransaction();

    // 1) Générer la référence
    $stmt = $pdo->query("SELECT MAX(id) FROM taches");
    $prochainId = ((int)$stmt->fetchColumn()) + 1;
    $reference = 'TCK-' . str_pad($prochainId, 6, '0', STR_PAD_LEFT);

    // 2) Calculer le SLA
    $stmt = $pdo->prepare("SELECT heures FROM sla_config WHERE categorie = ? AND priorite = ?");
    $stmt->execute([$categorie, $priorite]);
    $sla = $stmt->fetch();
    $slaHeures = $sla ? (int)$sla['heures'] : 48;

    // 3) Calculer l'échéance
    if (!$echeance) {
        $dt = new DateTime();
        $dt->add(new DateInterval("PT{$slaHeures}H"));
        $echeance = $dt->format('Y-m-d H:i:s');
    }

    // 4) Insertion du ticket
    $stmt = $pdo->prepare("INSERT INTO taches 
        (reference, titre, description, type_ticket, categorie, service_concerne, 
         siege, demandeur_nom, demandeur_service,
         priorite, sla_heures, date_echeance, date_resolution_prevue,
         createur_id, assigne_a_id, statut, avancement)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'a_faire', 0)");

    $stmt->execute([
        $reference,
        $titre,
        $description,
        $type,
        $categorie,
        $service,
        $siege,
        $demandeurNom,
        $demandeurService,
        $priorite,
        $slaHeures,
        $echeance,
        $echeance,
        $u['id'],
        $assigne
    ]);

    $id = (int)$pdo->lastInsertId();

    // ⚠️ VÉRIFICATION CRITIQUE
    if (!$id) {
        throw new Exception('Impossible de récupérer l\'ID de la tâche créée.');
    }

    // 5) Historique
    $pdo->prepare("INSERT INTO historique (tache_id, utilisateur_id, action, nouvelle_valeur)
                   VALUES (?, ?, 'création', ?)")
        ->execute([$id, $u['id'], $reference . ' - ' . $titre]);

    // 6) Upload des pièces jointes (SEULEMENT si un ID existe)
    if ($id && !empty($_FILES['fichiers']['name'][0])) {
        $uploadDir = __DIR__ . '/../uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $nb = count($_FILES['fichiers']['name']);
        for ($i = 0; $i < $nb; $i++) {
            if ($_FILES['fichiers']['error'][$i] !== UPLOAD_ERR_OK) continue;

            $nomOrig = basename($_FILES['fichiers']['name'][$i]);
            $ext     = strtolower(pathinfo($nomOrig, PATHINFO_EXTENSION));
            $allowed = ['pdf','doc','docx','xls','xlsx','jpg','jpeg','png','gif','txt','zip'];

            if (!in_array($ext, $allowed)) continue;
            if ($_FILES['fichiers']['size'][$i] > 10 * 1024 * 1024) continue;

            $nouveauNom = uniqid('pj_', true) . '.' . $ext;
            $cheminFull = $uploadDir . $nouveauNom;

            if (move_uploaded_file($_FILES['fichiers']['tmp_name'][$i], $cheminFull)) {
                $pdo->prepare("INSERT INTO pieces_jointes 
                    (tache_id, utilisateur_id, nom_fichier, chemin, type_mime, taille)
                    VALUES (?, ?, ?, ?, ?, ?)")
                    ->execute([
                        $id,
                        $u['id'],
                        $nomOrig,
                        'uploads/' . $nouveauNom,
                        $_FILES['fichiers']['type'][$i],
                        $_FILES['fichiers']['size'][$i]
                    ]);
            }
        }
    }

    $pdo->commit();

    echo json_encode([
        'success'   => true,
        'id'        => $id,
        'reference' => $reference,
        'sla'       => $slaHeures,
        'echeance'  => $echeance
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Erreur : ' . $e->getMessage()]);
}