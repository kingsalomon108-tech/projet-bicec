<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();

$stmt = $pdo->prepare("SELECT n.*, t.reference AS tache_ref, t.titre AS tache_titre
    FROM notifications n
    LEFT JOIN taches t ON t.id = n.tache_id
    WHERE n.utilisateur_id = ?
    ORDER BY n.date_creation DESC
    LIMIT 30");
$stmt->execute([$u['id']]);
$notifs = $stmt->fetchAll();

// Compter non lues
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE utilisateur_id = ? AND lue = 0");
$stmt->execute([$u['id']]);
$nonLues = (int)$stmt->fetchColumn();

echo json_encode([
    'notifications' => $notifs,
    'non_lues'      => $nonLues
]);