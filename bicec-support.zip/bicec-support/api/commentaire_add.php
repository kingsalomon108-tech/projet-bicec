<?php
require_once __DIR__ . '/notification_add.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();
$data = json_decode(file_get_contents('php://input'), true);

$tache_id = (int)($data['tache_id'] ?? 0);
$contenu  = trim($data['contenu'] ?? '');

if (!$tache_id || $contenu === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Champs manquants ou commentaire vide']);
    exit;
}

$stmt = $pdo->prepare("SELECT id FROM taches WHERE id = ?");
$stmt->execute([$tache_id]);
if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(['error' => 'Tâche introuvable']);
    exit;
}

try {
    $stmt = $pdo->prepare("INSERT INTO commentaires (tache_id, utilisateur_id, contenu) VALUES (?, ?, ?)");
    $stmt->execute([$tache_id, $u['id'], $contenu]);

    echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur SQL : ' . $e->getMessage()]);
}
// Récupérer la tâche et notifier le technicien assigné (s'il n'est pas l'auteur)
$stmt = $pdo->prepare("SELECT * FROM taches WHERE id = ?");
$stmt->execute([$tache_id]);
$tache = $stmt->fetch();

if ($tache && $tache['assigne_a_id'] && $tache['assigne_a_id'] != $u['id']) {
    creerNotification($pdo, $tache['assigne_a_id'], 'commentaire',
        'Nouveau commentaire',
        $u['nom'] . ' a commenté le ticket ' . ($tache['reference'] ?? '') . ' : ' . substr($contenu, 0, 80),
        $tache_id);
}