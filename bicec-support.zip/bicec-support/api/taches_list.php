<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();

$statut    = $_GET['statut']    ?? '';
$priorite  = $_GET['priorite']  ?? '';
$assigne   = $_GET['assigne']   ?? '';
$recherche = $_GET['q']         ?? '';
$mesTaches = $_GET['mes']       ?? '';
$categorie = $_GET['categorie'] ?? '';

$sql = "SELECT t.*, 
               u.nom AS assigne_nom, 
               c.nom AS createur_nom,
               (SELECT COUNT(*) FROM commentaires WHERE tache_id = t.id) AS nb_commentaires,
               (SELECT COUNT(*) FROM pieces_jointes WHERE tache_id = t.id) AS nb_pieces
        FROM taches t
        LEFT JOIN utilisateurs u ON u.id = t.assigne_a_id
        LEFT JOIN utilisateurs c ON c.id = t.createur_id
        WHERE 1=1";
$params = [];

// 🔒 Confidentialité : un membre ne voit que ses tâches
if ($u['role'] !== 'chef') {
    $sql .= " AND (t.assigne_a_id = ? OR t.createur_id = ?)";
    $params[] = $u['id'];
    $params[] = $u['id'];
}

if ($statut)    { $sql .= " AND t.statut = ?";        $params[] = $statut; }
if ($priorite)  { $sql .= " AND t.priorite = ?";      $params[] = $priorite; }
if ($categorie) { $sql .= " AND t.categorie = ?";     $params[] = $categorie; }
if ($assigne)   { $sql .= " AND t.assigne_a_id = ?";  $params[] = $assigne; }
if ($recherche) { $sql .= " AND t.titre LIKE ?";      $params[] = "%$recherche%"; }
if ($mesTaches === '1') { $sql .= " AND t.assigne_a_id = ?"; $params[] = $u['id']; }

$sql .= " ORDER BY 
    FIELD(t.priorite, 'urgente','haute','normale','basse'),
    t.date_creation DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
echo json_encode($stmt->fetchAll());