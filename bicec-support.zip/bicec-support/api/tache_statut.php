<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);  // ← IMPORTANT : n'affiche PAS les erreurs

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();
$data = json_decode(file_get_contents('php://input'), true);

$id         = (int)($data['id'] ?? 0);
$statut     = $data['statut'] ?? null;
$avancement = isset($data['avancement']) ? (int)$data['avancement'] : null;

if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'ID manquant']);
    exit;
}

// 🔒 Le chef ne peut PAS changer le statut
if (($u['role'] ?? '') === 'chef') {
    http_response_code(403);
    echo json_encode(['error' => 'Le chef ne peut pas modifier le statut des tickets.']);
    exit;
}

// Récupérer la tâche
$stmt = $pdo->prepare("SELECT * FROM taches WHERE id = ?");
$stmt->execute([$id]);
$tache = $stmt->fetch();

if (!$tache) {
    http_response_code(404);
    echo json_encode(['error' => 'Tâche introuvable']);
    exit;
}

// 🔒 Le membre ne peut modifier QUE ses propres tickets
if ($tache['assigne_a_id'] != $u['id']) {
    http_response_code(403);
    echo json_encode(['error' => 'Vous ne pouvez modifier que vos tickets.']);
    exit;
}

$updates = [];
$params  = [];

if ($statut) {
    $updates[] = "statut = ?";
    $params[]  = $statut;
    if ($statut === 'en_attente_validation') $updates[] = "avancement = 100";
}
if ($avancement !== null) {
    $updates[] = "avancement = ?";
    $params[]  = max(0, min(100, $avancement));
}
if (!$updates) {
    echo json_encode(['error' => 'Rien à modifier']);
    exit;
}

$params[] = $id;
$pdo->prepare("UPDATE taches SET " . implode(',', $updates) . " WHERE id = ?")->execute($params);

$pdo->prepare("INSERT INTO historique (tache_id, utilisateur_id, action, ancienne_valeur, nouvelle_valeur)
               VALUES (?, ?, 'changement statut', ?, ?)")
    ->execute([$id, $u['id'], $tache['statut'], $statut ?? $tache['statut']]);

echo json_encode(['success' => true]);