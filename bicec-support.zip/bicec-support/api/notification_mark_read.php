<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();
$data = json_decode(file_get_contents('php://input'), true);
$id = (int)($data['id'] ?? 0);

if ($id) {
    $pdo->prepare("UPDATE notifications SET lue = 1 WHERE id = ? AND utilisateur_id = ?")
        ->execute([$id, $u['id']]);
} else {
    // Tout marquer comme lu
    $pdo->prepare("UPDATE notifications SET lue = 1 WHERE utilisateur_id = ?")
        ->execute([$u['id']]);
}

echo json_encode(['success' => true]);