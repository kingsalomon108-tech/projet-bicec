<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$stmt = $pdo->query("SELECT id, nom, role FROM utilisateurs WHERE actif = 1 ORDER BY nom");
echo json_encode($stmt->fetchAll());