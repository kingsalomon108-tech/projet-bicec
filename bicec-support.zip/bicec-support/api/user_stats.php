<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$sql = "SELECT 
    u.id,
    u.nom,
    u.email,
    u.role,
    u.actif,
    u.date_creation,
    COUNT(t.id) AS total_taches,
    SUM(t.statut = 'a_faire') AS a_faire,
    SUM(t.statut = 'en_cours') AS en_cours,
    SUM(t.statut = 'en_attente_validation') AS en_attente,
    SUM(t.statut = 'valide') AS validees,
    SUM(t.date_echeance < CURDATE() AND t.statut NOT IN ('valide')) AS en_retard
    FROM utilisateurs u
    LEFT JOIN taches t ON t.assigne_a_id = u.id
    GROUP BY u.id
    ORDER BY u.role DESC, u.nom ASC";

$users = $pdo->query($sql)->fetchAll();

foreach ($users as &$u) {
    $u['taux'] = $u['total_taches'] > 0
        ? round(($u['validees'] / $u['total_taches']) * 100)
        : 0;
}

echo json_encode($users);