<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../libs/fpdf/fpdf.php';
exiger_connexion();

$u = utilisateur_actuel();
$isChef = $u['role'] === 'chef';

// Récupération des filtres
$statut    = $_GET['statut']    ?? '';
$priorite  = $_GET['priorite']  ?? '';
$categorie = $_GET['categorie'] ?? '';
$recherche = $_GET['q']         ?? '';

// Construction de la requête
$where = "WHERE 1=1";
$params = [];

// 🔒 Confidentialité
if (!$isChef) {
    $where .= " AND t.assigne_a_id = ?";
    $params[] = $u['id'];
}

if ($statut)    { $where .= " AND t.statut = ?";    $params[] = $statut; }
if ($priorite)  { $where .= " AND t.priorite = ?";  $params[] = $priorite; }
if ($categorie) { $where .= " AND t.categorie = ?"; $params[] = $categorie; }
if ($recherche) { 
    $where .= " AND (t.titre LIKE ? OR t.reference LIKE ?)"; 
    $params[] = "%$recherche%";
    $params[] = "%$recherche%";
}

$sql = "SELECT t.*, 
               u.nom AS assigne_nom,
               c.nom AS createur_nom,
               CASE 
                   WHEN t.date_echeance IS NOT NULL 
                        AND t.date_echeance < NOW() 
                        AND t.statut NOT IN ('valide') 
                   THEN 1 ELSE 0 
               END AS en_retard
        FROM taches t
        LEFT JOIN utilisateurs u ON u.id = t.assigne_a_id
        LEFT JOIN utilisateurs c ON c.id = t.createur_id
        $where
        ORDER BY 
            en_retard DESC,
            FIELD(t.priorite, 'urgente','haute','normale','basse'),
            t.date_creation DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$taches = $stmt->fetchAll();

// ============================================
// GÉNÉRATION DU PDF
// ============================================
class PDF extends FPDF {
    public $titreDoc = 'Liste des tickets';
    
    function Header() {
        // Logo BICEC (si présent)
      // Logo BICEC (seulement si c'est un vrai PNG)
$logoPath = __DIR__ . '/../assets/img/logo-bicec.png';
if (file_exists($logoPath)) {
    $info = @getimagesize($logoPath);
    if ($info && $info[2] === IMAGETYPE_PNG) {
        $this->Image($logoPath, 10, 8, 25);
    }
}
        
        // Titre
        $this->SetFont('Arial', 'B', 16);
        $this->SetTextColor(46, 26, 0);
        $this->Cell(0, 8, 'BICEC SUPPORT', 0, 1, 'C');
        
        $this->SetFont('Arial', '', 11);
        $this->SetTextColor(120, 120, 120);
        $this->Cell(0, 6, utf8_decode($this->titreDoc), 0, 1, 'C');
        
        $this->SetFont('Arial', '', 9);
        $this->Cell(0, 5, 'Genere le ' . date('d/m/Y a H:i'), 0, 1, 'C');
        
        // Ligne orange
        $this->SetDrawColor(230, 126, 0);
        $this->SetLineWidth(0.8);
        $this->Line(10, 35, 200, 35);
        $this->Ln(6);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(150, 150, 150);
        $this->Cell(0, 10, utf8_decode('Page ') . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
    
    // En-tête du tableau
    function TableHeader() {
        $this->SetFillColor(46, 26, 0);
        $this->SetTextColor(255, 255, 255);
        $this->SetFont('Arial', 'B', 8);
        $this->SetDrawColor(200, 200, 200);
        $this->SetLineWidth(0.2);
        
        $this->Cell(22, 8, 'Reference', 1, 0, 'C', true);
        $this->Cell(60, 8, 'Titre', 1, 0, 'C', true);
        $this->Cell(22, 8, 'Categorie', 1, 0, 'C', true);
        $this->Cell(28, 8, 'Technicien', 1, 0, 'C', true);
        $this->Cell(18, 8, 'Priorite', 1, 0, 'C', true);
        $this->Cell(20, 8, 'Statut', 1, 0, 'C', true);
        $this->Cell(20, 8, 'Echeance', 1, 1, 'C', true);
    }
    
    // Une ligne du tableau
    function LigneTache($t) {
        $retard = (int)$t['en_retard'] === 1;
        
        // Couleur selon retard
        if ($retard) {
            $this->SetFillColor(254, 226, 226);
            $this->SetTextColor(178, 34, 34);
        } else {
            $this->SetFillColor(255, 255, 255);
            $this->SetTextColor(50, 50, 50);
        }
        
        $this->SetFont('Arial', '', 8);
        
        $reference = utf8_decode($t['reference'] ?? '-');
        $titre = utf8_decode(substr($t['titre'] ?? '-', 0, 40));
        $categorie = utf8_decode(substr($t['categorie'] ?? '-', 0, 15));
        $tech = utf8_decode(substr($t['assigne_nom'] ?? 'Non assigne', 0, 18));
        $priorite = utf8_decode($t['priorite'] ?? '-');
        $statut = utf8_decode(str_replace('_', ' ', $t['statut'] ?? '-'));
        $echeance = $t['date_echeance'] ? date('d/m/Y', strtotime($t['date_echeance'])) : '-';
        
        $this->Cell(22, 7, $reference, 1, 0, 'L', true);
        $this->Cell(60, 7, $titre, 1, 0, 'L', true);
        $this->Cell(22, 7, $categorie, 1, 0, 'L', true);
        $this->Cell(28, 7, $tech, 1, 0, 'L', true);
        $this->Cell(18, 7, $priorite, 1, 0, 'C', true);
        $this->Cell(20, 7, $statut, 1, 0, 'C', true);
        $this->Cell(20, 7, $echeance, 1, 1, 'C', true);
    }
}

// Création du PDF
$pdf = new PDF('L', 'mm', 'A4'); // Paysage
$pdf->AliasNbPages();
$pdf->titreDoc = $isChef ? 'Liste complete des tickets' : 'Mes tickets';
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 20);

// Info utilisateur
$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(70, 70, 70);
$pdf->Cell(0, 6, utf8_decode('Utilisateur : ' . $u['nom'] . ' (' . ($isChef ? 'Chef d\'equipe' : 'Technicien') . ')'), 0, 1);
$pdf->Cell(0, 6, utf8_decode('Nombre de tickets : ' . count($taches)), 0, 1);
$pdf->Ln(3);

// Tableau
if (empty($taches)) {
    $pdf->SetFont('Arial', 'I', 11);
    $pdf->SetTextColor(150, 150, 150);
    $pdf->Cell(0, 20, utf8_decode('Aucun ticket a afficher.'), 0, 1, 'C');
} else {
    $pdf->TableHeader();
    foreach ($taches as $t) {
        $pdf->LigneTache($t);
    }
    
    // Résumé en bas
    $pdf->Ln(6);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetTextColor(46, 26, 0);
    
    $totalRetard = 0;
    foreach ($taches as $t) { if ((int)$t['en_retard'] === 1) $totalRetard++; }
    
    $pdf->Cell(0, 6, utf8_decode('Resume :'), 0, 1);
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(70, 70, 70);
    $pdf->Cell(0, 5, utf8_decode('- Total : ' . count($taches) . ' tickets'), 0, 1);
    $pdf->SetTextColor(178, 34, 34);
    $pdf->Cell(0, 5, utf8_decode('- En retard : ' . $totalRetard . ' tickets'), 0, 1);
}

// Nom du fichier
$nomFichier = 'tickets_bicec_' . date('Y-m-d_His') . '.pdf';

// Sortie
$pdf->Output('D', $nomFichier);
exit;