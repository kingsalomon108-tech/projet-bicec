<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_chef();

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = (int)($data['id'] ?? 0);

if (!$id) { http_response_code(400); echo json_encode(['error'=>'ID manquant']); exit; }

$pdo->prepare("DELETE FROM taches WHERE id = ?")->execute([$id]);
echo json_encode(['success' => true]);