<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();

// Stats globales
$stats = $pdo->query("SELECT 
    COUNT(*) AS total,
    SUM(statut='a_faire') AS a_faire,
    SUM(statut='en_cours') AS en_cours,
    SUM(statut='en_attente_validation') AS en_attente,
    SUM(statut='valide') AS valide,
    SUM(date_echeance < CURDATE() AND statut NOT IN ('valide')) AS en_retard
    FROM taches")->fetch();

// Charge par membre
$charge = $pdo->query("SELECT u.id, u.nom, 
    COUNT(t.id) AS total,
    SUM(t.statut IN ('en_cours','a_faire')) AS actives,
    SUM(t.statut='valide') AS terminees
    FROM utilisateurs u
    LEFT JOIN taches t ON t.assigne_a_id = u.id
    WHERE u.actif = 1
    GROUP BY u.id ORDER BY total DESC")->fetchAll();

// Mes stats
$stmt = $pdo->prepare("SELECT 
    COUNT(*) AS total,
    SUM(statut='valide') AS valide,
    SUM(date_echeance < CURDATE() AND statut NOT IN ('valide')) AS en_retard
    FROM taches WHERE assigne_a_id = ?");
$stmt->execute([$u['id']]);
$mesStats = $stmt->fetch();

echo json_encode(compact('stats','charge','mesStats'));