<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_connexion();

header('Content-Type: application/json');

$u = utilisateur_actuel();
$id = (int)($_GET['id'] ?? 0);
if (!$id) { http_response_code(400); echo json_encode(['error'=>'ID manquant']); exit; }

$stmt = $pdo->prepare("SELECT t.*, 
                              u.nom AS assigne_nom, 
                              c.nom AS createur_nom,
                              v.nom AS valideur_nom
                       FROM taches t
                       LEFT JOIN utilisateurs u ON u.id = t.assigne_a_id
                       LEFT JOIN utilisateurs c ON c.id = t.createur_id
                       LEFT JOIN utilisateurs v ON v.id = t.valide_par
                       WHERE t.id = ?");
$stmt->execute([$id]);
$tache = $stmt->fetch();
if (!$tache) { http_response_code(404); echo json_encode(['error'=>'Introuvable']); exit; }

// 🔒 Confidentialité : un membre ne peut voir que ses tâches
if ($u['role'] !== 'chef' 
    && $tache['assigne_a_id'] != $u['id'] 
    && $tache['createur_id'] != $u['id']) {
    http_response_code(403);
    echo json_encode(['error' => 'Accès refusé à cette tâche']);
    exit;
}

// Commentaires
$stmt = $pdo->prepare("SELECT c.*, u.nom AS auteur FROM commentaires c
                       LEFT JOIN utilisateurs u ON u.id = c.utilisateur_id
                       WHERE c.tache_id = ? ORDER BY c.date_creation ASC");
$stmt->execute([$id]);
$commentaires = $stmt->fetchAll();

// Historique
$stmt = $pdo->prepare("SELECT h.*, u.nom AS auteur FROM historique h
                       LEFT JOIN utilisateurs u ON u.id = h.utilisateur_id
                       WHERE h.tache_id = ? ORDER BY h.date_creation DESC LIMIT 20");
$stmt->execute([$id]);
$historique = $stmt->fetchAll();

// Pièces jointes
$stmt = $pdo->prepare("SELECT p.*, u.nom AS auteur FROM pieces_jointes p
                       LEFT JOIN utilisateurs u ON u.id = p.utilisateur_id
                       WHERE p.tache_id = ? ORDER BY p.date_upload DESC");
$stmt->execute([$id]);
$pieces = $stmt->fetchAll();

echo json_encode(compact('tache','commentaires','historique','pieces'));