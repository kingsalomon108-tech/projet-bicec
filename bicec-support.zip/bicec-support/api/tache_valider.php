<?php
require_once __DIR__ . '/notification_add.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
exiger_chef();

header('Content-Type: application/json');

$u = utilisateur_actuel();
$data = json_decode(file_get_contents('php://input'), true);
$id     = (int)($data['id'] ?? 0);
$action = $data['action'] ?? '';
$motif  = trim($data['motif'] ?? '');

if (!$id || !in_array($action, ['valider','refuser'])) {
    http_response_code(400);
    echo json_encode(['error'=>'Paramètres invalides']);
    exit;
}

// Récupérer la tâche
$stmt = $pdo->prepare("SELECT * FROM taches WHERE id = ?");
$stmt->execute([$id]);
$tache = $stmt->fetch();
if (!$tache) { http_response_code(404); echo json_encode(['error'=>'Tâche introuvable']); exit; }

if ($action === 'valider') {
    $pdo->prepare("UPDATE taches SET statut='valide', valide_par=?, motif_refus=NULL WHERE id=?")
        ->execute([$u['id'], $id]);
    $actionTexte = 'validée';
} else {
    if (!$motif) { http_response_code(400); echo json_encode(['error'=>'Motif requis']); exit; }
    $pdo->prepare("UPDATE taches SET statut='en_cours', valide_par=?, motif_refus=? WHERE id=?")
        ->execute([$u['id'], $motif, $id]);
    $actionTexte = 'refusée';
}

// Historique
$pdo->prepare("INSERT INTO historique (tache_id, utilisateur_id, action, nouvelle_valeur)
               VALUES (?, ?, ?, ?)")
    ->execute([$id, $u['id'], "Tâche $actionTexte", $motif ?: '']);

echo json_encode(['success' => true]);
// Notifier le technicien assigné
if ($tache['assigne_a_id']) {
    if ($action === 'valider') {
        creerNotification($pdo, $tache['assigne_a_id'], 'validation',
            'Ticket validé',
            'Votre ticket ' . ($tache['reference'] ?? '') . ' a été validé.',
            $id);
    } else {
        creerNotification($pdo, $tache['assigne_a_id'], 'refus',
            'Ticket refusé',
            'Votre ticket ' . ($tache['reference'] ?? '') . ' a été refusé. Motif : ' . $motif,
            $id);
    }
}