<?php
/**
 * Helper pour créer une notification
 * À inclure dans les autres fichiers API
 */
function creerNotification($pdo, $userId, $type, $titre, $message, $tacheId = null) {
    if (!$userId) return;
    try {
        $stmt = $pdo->prepare("INSERT INTO notifications 
            (utilisateur_id, type, titre, message, tache_id) 
            VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $type, $titre, $message, $tacheId]);
    } catch (Exception $e) {
        // Silencieux : on ne bloque pas l'action principale
    }
}