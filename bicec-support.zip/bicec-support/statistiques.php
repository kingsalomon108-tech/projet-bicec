<?php
require_once 'config/db.php';
require_once 'includes/auth.php';
exiger_chef();

$titre = 'Statistiques';
$u = utilisateur_actuel();

include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/bg.php';
?>

<div class="page-header">
    <div>
        <h1>Statistiques</h1>
        <p class="subtitle">Vue d'ensemble de l'activité du support</p>
    </div>
    <button class="btn btn-ghost" onclick="chargerStats()">
        <i data-lucide="refresh-cw"></i> Actualiser
    </button>
</div>

<!-- Cartes statistiques -->
<div class="stats-grid" id="stats-cards">
    <div class="stat-card">
        <div class="stat-value" id="stat-total">-</div>
        <div class="stat-label">Total tickets</div>
    </div>
    <div class="stat-card warning">
        <div class="stat-value" id="stat-en-cours">-</div>
        <div class="stat-label">En cours</div>
    </div>
    <div class="stat-card success">
        <div class="stat-value" id="stat-valide">-</div>
        <div class="stat-label">Validés</div>
    </div>
    <div class="stat-card danger">
        <div class="stat-value" id="stat-retard">-</div>
        <div class="stat-label">En retard</div>
    </div>
</div>

<!-- Taux de complétion -->
<div class="taux-completion-card">
    <div class="taux-header">
        <div>
            <h3>Taux de complétion global</h3>
            <p>Proportion de tickets validés sur le total</p>
        </div>
        <div class="taux-valeur" id="taux-valeur">-</div>
    </div>
    <div class="progress-bar progress-lg">
        <span id="taux-progress" style="width:0%"></span>
    </div>
</div>

<!-- Graphiques -->
<div class="charts-grid">
    <!-- Graphique : Charge par technicien -->
    <div class="chart-card chart-wide">
        <div class="chart-header">
            <h3>
                <i data-lucide="users"></i>
                Charge par technicien
            </h3>
        </div>
        <div class="chart-body">
            <canvas id="chartCharge"></canvas>
        </div>
    </div>

    <!-- Camembert : Statut -->
    <div class="chart-card">
        <div class="chart-header">
            <h3>
                <i data-lucide="pie-chart"></i>
                Répartition par statut
            </h3>
        </div>
        <div class="chart-body">
            <canvas id="chartStatut"></canvas>
        </div>
    </div>

    <!-- Camembert : Priorité -->
    <div class="chart-card">
        <div class="chart-header">
            <h3>
                <i data-lucide="alert-circle"></i>
                Répartition par priorité
            </h3>
        </div>
        <div class="chart-body">
            <canvas id="chartPriorite"></canvas>
        </div>
    </div>

    <!-- Graphique : Évolution -->
    <div class="chart-card chart-wide">
        <div class="chart-header">
            <h3>
                <i data-lucide="trending-up"></i>
                Évolution des 7 derniers jours
            </h3>
        </div>
        <div class="chart-body">
            <canvas id="chartEvolution"></canvas>
        </div>
    </div>
</div>

<!-- Top 5 tickets urgents -->
<div class="top-urgents-card">
    <div class="chart-header">
        <h3>
            <i data-lucide="flame"></i>
            Top 5 des tickets urgents
        </h3>
    </div>
    <div id="top-urgents" class="top-urgents-list">
        <div class="loading">Chargement</div>
    </div>
</div>

<?php include 'includes/bg-end.php'; ?>
<?php include 'includes/footer.php'; ?>