<?php
require_once 'config/db.php';
require_once 'includes/auth.php';
exiger_chef();

$titre = 'Validation';
$u = utilisateur_actuel();

include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/bg.php';
?>

<div class="page-header">
    <div>
        <h1>Validation des tickets</h1>
        <p class="subtitle">Tickets terminés en attente de votre décision</p>
    </div>
    <div class="badge-compteur" id="compteur-validation">
        <i data-lucide="clock"></i>
        <span id="compteur-nb">0</span> en attente
    </div>
</div>

<div id="validation-container" class="validation-grid">
    <div class="loading">Chargement</div>
</div>

<!-- Modal Détail -->
<div id="modal-detail" class="modal">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h2>Détail du ticket</h2>
            <button class="modal-close" onclick="fermerModalDetail()">
                <i data-lucide="x"></i>
            </button>
        </div>
        <div id="detail-body"></div>
    </div>
</div>

<?php include 'includes/bg-end.php'; ?>
<?php include 'includes/footer.php'; ?>