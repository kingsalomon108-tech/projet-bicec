<?php
require_once 'config/db.php';
require_once 'includes/auth.php';

$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $mdp   = $_POST['mot_de_passe'] ?? '';

    if ($email && $mdp) {
        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ? AND actif = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($mdp, $user['mot_de_passe'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['nom']     = $user['nom'];
            $_SESSION['role']    = $user['role'];
            header('Location: dashboard.php');
            exit;
        } else {
            $erreur = "Email ou mot de passe incorrect.";
        }
    } else {
        $erreur = "Veuillez remplir tous les champs.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion — BICEC Support</title>
    <link rel="icon" type="image/png" href="assets/img/logo-bicec.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="page-login">
    <div class="login-box">
        <div class="login-logo">
            <img src="assets/img/logo-bicec.png" alt="BICEC">
        </div>
        <h1>BICEC Support</h1>
        <p class="subtitle">Gestion des tickets de l'équipe</p>

        <?php if ($erreur): ?>
            <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="off">
            <label>Email</label>
            <input type="email" name="email" required autofocus placeholder="votre.email@bicec.cm">

            <label>Mot de passe</label>
            <input type="password" name="mot_de_passe" required placeholder="••••••••">

            <button type="submit">Se connecter</button>
        </form>
    </div>
</body>
</html>